#!/bin/bash
# Создает полноценные webpack stubs для недостающих chunks

TARGET=${1:-/var/www/panel.tanukicode.one/_next/static/chunks}

cd "$TARGET" || exit 1

echo "Создание webpack stubs..."

cat > 8721-5d442c1fafde9ff3.js << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8721],{8721:function(e,t,n){n.r(t);}}]);
CHUNK

cat > 3756.c23cf8b948096812.js << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3756],{3756:function(e,t,n){n.r(t);}}]);
CHUNK

cat > e0368f7a.67e5351a7e148781.js << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[5661],{5661:function(e,t,n){n.r(t);}}]);
CHUNK

cat > 7063.8747869763ba64b7.js << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7063],{7063:function(e,t,n){n.r(t);}}]);
CHUNK

cat > 4877.2bf928f05edcd565.js << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4877],{4877:function(e,t,n){n.r(t);}}]);
CHUNK

mkdir -p "app/(header)"
cat > "app/(header)/page-4fd122eacad7265c.js" << 'CHUNK'
"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[],{}]);
CHUNK

echo "✅ Созданы webpack stubs для 6 chunks"
