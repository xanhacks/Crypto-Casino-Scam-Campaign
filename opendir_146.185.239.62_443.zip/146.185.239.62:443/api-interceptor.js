// Скрипт для перехвата API запросов
// Добавьте его в HTML перед всеми другими скриптами

(function() {
  'use strict';
  
  // Хранилище для перехваченных запросов
  window.__API_CALLS__ = [];
  
  // Перехват fetch
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const url = args[0];
    const options = args[1] || {};
    
    // Логируем все запросы
    if (typeof url === 'string') {
      const callInfo = {
        type: 'fetch',
        url: url,
        method: options.method || 'GET',
        timestamp: new Date().toISOString()
      };
      
      console.log('[API INTERCEPTOR]', callInfo);
      window.__API_CALLS__.push(callInfo);
      
      // Если это API запрос - блокируем или возвращаем mock данные
      if (url.includes('/api/')) {
        console.warn('[API BLOCKED]', url);
        
        // Возвращаем mock данные в зависимости от endpoint
        return Promise.resolve(new Response(JSON.stringify({
          success: true,
          data: getMockData(url),
          message: 'Mock data'
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        }));
      }
    }
    
    return originalFetch.apply(this, args);
  };
  
  // Перехват XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function() {
    const xhr = new originalXHR();
    const originalOpen = xhr.open;
    
    xhr.open = function(method, url, ...rest) {
      const callInfo = {
        type: 'xhr',
        url: url,
        method: method,
        timestamp: new Date().toISOString()
      };
      
      console.log('[API INTERCEPTOR XHR]', callInfo);
      window.__API_CALLS__.push(callInfo);
      
      return originalOpen.apply(this, [method, url, ...rest]);
    };
    
    return xhr;
  };
  
  // Mock данные для разных endpoints
  function getMockData(url) {
    if (url.includes('/user')) {
      return {
        id: 1,
        name: 'Demo User',
        email: 'demo@example.com'
      };
    }
    
    if (url.includes('/stats')) {
      return {
        total: 0,
        today: 0,
        chart: []
      };
    }
    
    if (url.includes('/domains')) {
      return {
        domains: [],
        total: 0
      };
    }
    
    // Дефолтный ответ
    return {
      items: [],
      total: 0
    };
  }
  
  // Функция для экспорта собранных данных
  window.exportAPICalls = function() {
    const data = JSON.stringify(window.__API_CALLS__, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'api-calls-' + Date.now() + '.json';
    a.click();
    console.log('[API INTERCEPTOR] Экспортировано запросов:', window.__API_CALLS__.length);
  };
  
  console.log('[API INTERCEPTOR] Активирован. Используйте window.exportAPICalls() для экспорта данных.');
})();

