import puppeteer from 'puppeteer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read configuration
const domain = fs.readFileSync(path.join(__dirname, 'domain.txt'), 'utf-8').trim().replace(/\/$/, '');
const cookiesString = fs.readFileSync(path.join(__dirname, 'cookies.txt'), 'utf-8').trim();

// Parse cookies
const cookiesBase = cookiesString.split(';').map(cookie => {
  const [name, value] = cookie.trim().split('=');
  return { name, value, domain: domain };
});

console.log('🎨 STATIC SITE COPY - Без React/JS\n');
console.log(`Домен: ${domain}`);
console.log(`Cookies: ${cookiesBase.length}\n`);

const outputDir = path.join(__dirname, `${domain}_static`);

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

async function copyPageStatic(url, filename) {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage'
    ]
  });

  const page = await browser.newPage();
  
  // Set cookies
  await page.setCookie(...cookiesBase);
  
  console.log(`📄 Загрузка: ${url}`);
  
  // Go to page and wait for full render
  await page.goto(url, {
    waitUntil: 'networkidle0',
    timeout: 60000
  });
  
  // Wait extra time for React to fully render
  await page.waitForTimeout(3000);
  
  // Get fully rendered HTML
  const html = await page.evaluate(() => {
    // Remove all scripts to make it static
    document.querySelectorAll('script').forEach(el => el.remove());
    
    // Remove React-specific attributes
    document.querySelectorAll('[data-reactroot], [data-reactid]').forEach(el => {
      el.removeAttribute('data-reactroot');
      el.removeAttribute('data-reactid');
    });
    
    // Inline all styles
    const styles = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    styles.forEach(link => {
      // Can't inline external CSS in this context, but we keep the links
    });
    
    return '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
  });
  
  // Save HTML
  const outputPath = path.join(outputDir, filename);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html);
  
  console.log(`   ✅ Сохранено: ${filename} (${(html.length/1024).toFixed(1)} KB)\n`);
  
  await browser.close();
}

async function main() {
  try {
    // Copy main page
    await copyPageStatic(`https://${domain}`, 'index.html');
    
    console.log('✅ Статический сайт создан!');
    console.log(`📁 Директория: ${outputDir}\n`);
    
    // Show files
    const files = fs.readdirSync(outputDir);
    console.log('Файлы:');
    files.forEach(f => {
      const stat = fs.statSync(path.join(outputDir, f));
      console.log(`  - ${f} (${(stat.size/1024).toFixed(1)} KB)`);
    });
    
  } catch (error) {
    console.error('❌ Ошибка:', error.message);
    process.exit(1);
  }
}

main();

