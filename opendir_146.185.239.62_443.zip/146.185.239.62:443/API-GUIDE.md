# 🔍 Руководство по работе с API данными

## Метод 1: Через Browser DevTools (рекомендуется)

### Шаг 1: Открыть оригинальный сайт с cookies
1. Откройте `https://gambler-work.com` в браузере
2. Авторизуйтесь (используйте cookies из cookies.txt)

### Шаг 2: Открыть DevTools
1. Нажмите `F12` или `Ctrl+Shift+I`
2. Перейдите на вкладку **Network**
3. В фильтре выберите **Fetch/XHR**

### Шаг 3: Собрать API запросы
1. Обновите страницу (`F5`)
2. Понаблюдайте за запросами в Network
3. Для каждого запроса:
   - **URL**: куда идет запрос (например `/api/users`)
   - **Method**: GET/POST/PUT/DELETE
   - **Response**: какие данные возвращаются

### Шаг 4: Скопировать данные
1. Кликните на запрос
2. Перейдите на вкладку **Response**
3. Скопируйте JSON данные
4. Сохраните в файл `/var/www/html/mock-data/{endpoint-name}.json`

## Метод 2: Через API Interceptor (автоматический)

### Установка

1. Скопируйте содержимое `/var/www/html/api-interceptor.js`
2. Откройте оригинальный сайт в браузере
3. Откройте DevTools Console (`F12` → Console)
4. Вставьте весь код из `api-interceptor.js` и нажмите Enter

### Использование

1. Работайте с сайтом как обычно
2. Все API запросы будут логироваться в консоль
3. Когда закончите, выполните в консоли:
   ```javascript
   window.exportAPICalls()
   ```
4. Скачается файл `api-calls-{timestamp}.json` со всеми запросами

## Создание Mock данных

### Структура файлов

```
/var/www/html/mock-data/
├── users.json          # GET /api/users
├── stats.json          # GET /api/stats
├── domains.json        # GET /api/domains
├── deposits.json       # GET /api/deposits
└── ...
```

### Пример файла mock-data/users.json

```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Admin User",
    "email": "admin@example.com",
    "role": "admin",
    "balance": 1000
  }
}
```

### Пример файла mock-data/stats.json

```json
{
  "success": true,
  "data": {
    "total_users": 150,
    "active_domains": 25,
    "revenue": 50000,
    "chart": [
      { "date": "2024-01-01", "value": 100 },
      { "date": "2024-01-02", "value": 150 },
      { "date": "2024-01-03", "value": 200 }
    ]
  }
}
```

## Интеграция Mock данных

### Вариант 1: Статический вывод (простой)

Измените HTML напрямую, заменив динамические блоки на статические:

```html
<!-- Вместо динамической загрузки -->
<div id="user-info">Loading...</div>

<!-- Статические данные -->
<div id="user-info">
  <h2>Admin User</h2>
  <p>Email: admin@example.com</p>
  <p>Balance: $1000</p>
</div>
```

### Вариант 2: Mock API Server (продвинутый)

Создайте файл `/var/www/html/mock-api-server.js`:

```javascript
import express from 'express';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = 3001;

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});

app.get('/api/*', (req, res) => {
  const endpoint = req.path.replace('/api/', '');
  const mockFile = path.join('/var/www/html/mock-data', \`\${endpoint}.json\`);
  
  if (fs.existsSync(mockFile)) {
    const data = JSON.parse(fs.readFileSync(mockFile, 'utf-8'));
    res.json(data);
  } else {
    res.json({ success: false, error: 'Mock not found' });
  }
});

app.listen(PORT, () => {
  console.log(\`Mock API server running on http://localhost:\${PORT}\`);
});
```

Запустите:
```bash
cd /var/www/html
npm install express
node mock-api-server.js
```

Обновите fetch в HTML:
```javascript
window.fetch = function(url, ...args) {
  if (url.includes('/api/')) {
    url = 'http://localhost:3001' + url;
  }
  return originalFetch(url, ...args);
};
```

## Текущая защита

Сейчас установлена **ULTIMATE защита**, которая:
- ✅ Блокирует все ошибки загрузки chunks
- ✅ Блокирует уведомления об ошибках
- ✅ Возвращает пустые данные для `/api/*` запросов
- ✅ Подавляет все console.error с ChunkLoadError
- ✅ Предотвращает "Application error"

## Следующие шаги

1. **Собрать реальные данные** с оригинального сайта (DevTools)
2. **Создать mock файлы** в `/var/www/html/mock-data/`
3. **Выбрать подход**:
   - Статический (проще, быстрее)
   - Mock API Server (гибче, реалистичнее)
4. **Протестировать** на `panel.tanukicode.one`

## Полезные команды

```bash
# Найти все API вызовы в консоли браузера
window.__API_CALLS__

# Экспортировать собранные данные
window.exportAPICalls()

# Проверить защиту
grep -c "ULTIMATE" /var/www/panel.tanukicode.one/index.html

# Применить новую защиту
cd /var/www/html
./copy-and-deploy.sh
```

