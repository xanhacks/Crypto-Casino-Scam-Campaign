import fs from 'fs';
import path from 'path';

const targetDir = process.argv[2] || '/var/www/panel.tanukicode.one';

// Проблемные chunks которые нужно отключить
const badChunks = [
  '8721-5d442c1fafde9ff3',
  '3756.c23cf8b948096812',
  'e0368f7a.67e5351a7e148781',
  '7063.8747869763ba64b7',
  '4877.2bf928f05edcd565',
  'page-4fd122eacad7265c'
];

function disableChunks(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  let count = 0;
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    
    if (entry.isDirectory()) {
      count += disableChunks(fullPath);
    } else if (entry.name.endsWith('.html')) {
      let html = fs.readFileSync(fullPath, 'utf-8');
      let modified = false;
      
      // Удаляем ссылки на проблемные chunks из HTML
      for (const chunk of badChunks) {
        const pattern = new RegExp(`I\\[[^\\]]+,\\[[^\\]]*"[^"]*${chunk.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[^"]*"[^\\]]*\\][^\\]]*\\]`, 'g');
        if (pattern.test(html)) {
          html = html.replace(pattern, 'null');
          modified = true;
        }
      }
      
      if (modified) {
        fs.writeFileSync(fullPath, html);
        console.log(`✓ ${path.relative(targetDir, fullPath)}`);
        count++;
      }
    }
  }
  
  return count;
}

console.log(`\nОтключение проблемных chunks...\n`);
const total = disableChunks(targetDir);
console.log(`\n✅ ${total} файлов обновлено\n`);

