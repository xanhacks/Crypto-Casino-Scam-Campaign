// ========================================
// API DATA COLLECTOR
// Вставьте этот код в консоль браузера на gambler-work.com
// ========================================

(function() {
  'use strict';
  
  console.log('%c[API COLLECTOR] Запущен', 'color: green; font-weight: bold');
  
  // Хранилище для данных
  window.__COLLECTED_DATA__ = {
    endpoints: {},
    wsMessages: [],
    metadata: {
      startTime: new Date().toISOString(),
      domain: window.location.origin
    }
  };
  
  // 1. Перехват XHR
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;
  
  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._method = method;
    this._url = url;
    return originalXHROpen.apply(this, [method, url, ...args]);
  };
  
  XMLHttpRequest.prototype.send = function(...args) {
    const xhr = this;
    
    const originalOnLoad = xhr.onload;
    xhr.onload = function() {
      if (xhr._url && xhr._url.includes('/api/')) {
        try {
          const data = JSON.parse(xhr.responseText);
          const endpoint = xhr._url.replace(window.location.origin, '');
          
          window.__COLLECTED_DATA__.endpoints[endpoint] = {
            method: xhr._method,
            status: xhr.status,
            response: data,
            timestamp: new Date().toISOString()
          };
          
          console.log(`%c[COLLECTED] ${xhr._method} ${endpoint}`, 'color: blue', data);
        } catch (e) {
          console.warn('[COLLECTOR] Failed to parse:', xhr._url, e);
        }
      }
      
      if (originalOnLoad) {
        originalOnLoad.apply(this, arguments);
      }
    };
    
    return originalXHRSend.apply(this, args);
  };
  
  // 2. Перехват fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = args[0];
    
    const response = await originalFetch.apply(this, args);
    
    if (typeof url === 'string' && url.includes('/api/')) {
      const clonedResponse = response.clone();
      try {
        const data = await clonedResponse.json();
        const endpoint = url.replace(window.location.origin, '');
        
        window.__COLLECTED_DATA__.endpoints[endpoint] = {
          method: args[1]?.method || 'GET',
          status: response.status,
          response: data,
          timestamp: new Date().toISOString()
        };
        
        console.log(`%c[COLLECTED] fetch ${endpoint}`, 'color: blue', data);
      } catch (e) {
        console.warn('[COLLECTOR] Failed to parse fetch:', url, e);
      }
    }
    
    return response;
  };
  
  // 3. Перехват WebSocket
  const originalWebSocket = window.WebSocket;
  window.WebSocket = function(...args) {
    const ws = new originalWebSocket(...args);
    
    console.log('%c[WS] Connected to:', 'color: purple', args[0]);
    
    const originalOnMessage = ws.onmessage;
    ws.onmessage = function(event) {
      try {
        const data = JSON.parse(event.data);
        window.__COLLECTED_DATA__.wsMessages.push({
          data: data,
          timestamp: new Date().toISOString()
        });
        console.log('%c[WS MESSAGE]', 'color: purple', data);
      } catch (e) {
        // Not JSON
      }
      
      if (originalOnMessage) {
        originalOnMessage.apply(this, arguments);
      }
    };
    
    return ws;
  };
  
  // 4. Функция для экспорта
  window.exportCollectedData = function() {
    const data = JSON.stringify(window.__COLLECTED_DATA__, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'api-data-' + Date.now() + '.json';
    a.click();
    URL.revokeObjectURL(url);
    
    console.log('%c[EXPORTED]', 'color: green; font-weight: bold', 
      'Собрано endpoints:', Object.keys(window.__COLLECTED_DATA__.endpoints).length,
      'WS сообщений:', window.__COLLECTED_DATA__.wsMessages.length
    );
  };
  
  // 5. Функция для создания mock файлов
  window.generateMockFiles = function() {
    const mockData = {};
    
    for (const [endpoint, info] of Object.entries(window.__COLLECTED_DATA__.endpoints)) {
      // Убираем параметры из endpoint для имени файла
      const cleanEndpoint = endpoint.split('?')[0].replace(/^\/api\//, '').replace(/\//g, '_');
      mockData[cleanEndpoint] = info.response;
    }
    
    console.log('%c[MOCK FILES]', 'color: orange; font-weight: bold');
    console.log('Создайте следующие файлы в /var/www/html/mock-data/:\n');
    
    for (const [filename, data] of Object.entries(mockData)) {
      console.log(`%c${filename}.json`, 'color: cyan');
      console.log(JSON.stringify(data, null, 2));
      console.log('\n---\n');
    }
    
    return mockData;
  };
  
  console.log('%c[API COLLECTOR] Готов!', 'color: green; font-weight: bold');
  console.log('%cИспользуйте:', 'font-weight: bold');
  console.log('  window.exportCollectedData()  - экспортировать все данные');
  console.log('  window.generateMockFiles()    - показать mock файлы');
  console.log('  window.__COLLECTED_DATA__     - просмотр собранных данных');
})();

