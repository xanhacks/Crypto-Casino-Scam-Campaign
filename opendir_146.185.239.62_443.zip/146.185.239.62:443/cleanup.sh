#!/bin/bash

# Очистка старых скачанных версий сайта

SOURCE_DIR="/var/www/html"
DOMAIN=$(cat /var/www/html/domain.txt | tr -d '\n\r' | sed 's|/$||' | sed 's|https\?://||')

echo "=== Cleanup Old Downloads ==="
echo ""

# Find all downloaded versions
DOWNLOADS=$(ls -dt ${SOURCE_DIR}/${DOMAIN}* 2>/dev/null)
COUNT=$(echo "$DOWNLOADS" | grep -v '^$' | wc -l)

if [ $COUNT -eq 0 ]; then
  echo "✓ No old downloads found"
  exit 0
fi

echo "Found $COUNT downloaded versions:"
echo "$DOWNLOADS" | nl -w2 -s'. '
echo ""

# Keep latest, remove others
LATEST=$(echo "$DOWNLOADS" | head -1)
TO_REMOVE=$(echo "$DOWNLOADS" | tail -n +2)

if [ -z "$TO_REMOVE" ]; then
  echo "✓ Only one version exists (keeping it)"
  exit 0
fi

echo "Will keep: $LATEST"
echo ""
echo "Will remove:"
echo "$TO_REMOVE" | nl -w2 -s'. '
echo ""

read -p "Remove old versions? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
  echo "❌ Cancelled"
  exit 0
fi

# Remove old versions
REMOVED=0
while IFS= read -r dir; do
  if [ -n "$dir" ] && [ -d "$dir" ]; then
    SIZE=$(du -sh "$dir" | cut -f1)
    rm -rf "$dir"
    echo "  ✓ Removed: $(basename $dir) ($SIZE)"
    REMOVED=$((REMOVED + 1))
  fi
done <<< "$TO_REMOVE"

echo ""
echo "✅ Removed $REMOVED old versions"
echo "✓ Kept latest: $(basename $LATEST)"

