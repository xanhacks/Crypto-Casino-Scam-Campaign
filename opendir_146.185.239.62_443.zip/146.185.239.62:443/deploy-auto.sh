#!/bin/bash

# Автоматическое развертывание без подтверждения

SOURCE_DIR="/var/www/html"
TARGET_DIR="/var/www/panel.tanukicode.one"
DOMAIN=$(cat /var/www/html/domain.txt | tr -d '\n\r' | sed 's|/$||' | sed 's|https\?://||')

echo "=== Auto Deployment ==="
echo "Domain: $DOMAIN"
echo "Target: $TARGET_DIR"

# Find latest downloaded site
LATEST_SITE=$(ls -dt ${SOURCE_DIR}/${DOMAIN}* 2>/dev/null | head -1)

if [ -z "$LATEST_SITE" ]; then
  echo "❌ No downloaded site found"
  exit 1
fi

# Check nested directory
NESTED_DIR="${LATEST_SITE}/${DOMAIN}"
if [ -d "$NESTED_DIR" ]; then
  SOURCE_FILES="$NESTED_DIR"
else
  SOURCE_FILES="$LATEST_SITE"
fi

FILE_COUNT=$(find "$SOURCE_FILES" -type f | wc -l)
echo "Files: $FILE_COUNT"

# Backup
BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
if [ -d "$TARGET_DIR" ] && [ "$(ls -A $TARGET_DIR)" ]; then
  mkdir -p "$BACKUP_DIR"
  cp -r "$TARGET_DIR"/* "$BACKUP_DIR"/ 2>/dev/null || true
  echo "✓ Backup: $BACKUP_DIR"
fi

# Deploy
rm -rf "${TARGET_DIR}"/*
cp -r "$SOURCE_FILES"/* "$TARGET_DIR"/
chown -R www-data:www-data "$TARGET_DIR" 2>/dev/null || true
chmod -R 755 "$TARGET_DIR" 2>/dev/null || true

echo "✅ Deployed $(find $TARGET_DIR -type f | wc -l) files to $TARGET_DIR"

