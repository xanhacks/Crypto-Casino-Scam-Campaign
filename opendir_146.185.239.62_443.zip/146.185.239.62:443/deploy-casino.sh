#!/bin/bash

TARGET_DIR="/var/www/casino.tanukicode.one"
SOURCE_BASE="/var/www/html"

echo ""
echo "🎰 DEPLOY TO CASINO.TANUKICODE.ONE"
echo "════════════════════════════════════════"
echo ""

# Найти последнюю скачанную директорию
LATEST_DIR=$(find "$SOURCE_BASE" -maxdepth 1 -type d -name "*.com*" -o -name "*inspin*" -o -name "*gambler*" 2>/dev/null | sort -r | head -1)

if [ -z "$LATEST_DIR" ]; then
  echo "❌ Не найдена скачанная директория!"
  echo "Запустите сначала: ./run.sh"
  exit 1
fi

# Найти директорию с файлами внутри (вложенная структура domain/domain/)
CONTENT_DIR=$(find "$LATEST_DIR" -mindepth 1 -maxdepth 1 -type d | head -1)

if [ -z "$CONTENT_DIR" ]; then
  echo "❌ Пустая директория: $LATEST_DIR"
  exit 1
fi

echo "📂 Источник: $CONTENT_DIR"
echo "🎯 Цель: $TARGET_DIR"
echo ""

# Проверка что директория содержит файлы
FILE_COUNT=$(find "$CONTENT_DIR" -type f | wc -l)
if [ "$FILE_COUNT" -eq 0 ]; then
  echo "❌ В директории нет файлов!"
  exit 1
fi

echo "📊 Найдено файлов: $FILE_COUNT"
echo ""

# Создать backup если целевая директория существует
if [ -d "$TARGET_DIR" ] && [ "$(ls -A $TARGET_DIR 2>/dev/null)" ]; then
  BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
  echo "💾 Создание backup..."
  echo "   $BACKUP_DIR"
  cp -r "$TARGET_DIR" "$BACKUP_DIR"
  echo "   ✅ Backup создан"
  echo ""
fi

# Удалить существующие файлы
if [ -d "$TARGET_DIR" ]; then
  echo "🗑️  Удаление старых файлов..."
  rm -rf "$TARGET_DIR"/*
  echo "   ✅ Удалено"
else
  echo "📁 Создание директории..."
  mkdir -p "$TARGET_DIR"
  echo "   ✅ Создана"
fi
echo ""

# Копировать новые файлы
echo "📦 Копирование файлов..."
cp -r "$CONTENT_DIR"/* "$TARGET_DIR"/
echo "   ✅ Скопировано"
echo ""

# Установить права
echo "🔒 Установка прав доступа..."
chown -R www-data:www-data "$TARGET_DIR" 2>/dev/null || chown -R root:root "$TARGET_DIR"
chmod -R 755 "$TARGET_DIR"
echo "   ✅ Права установлены"
echo ""

# Показать статистику
echo "════════════════════════════════════════"
echo "✅ РАЗВЕРТЫВАНИЕ ЗАВЕРШЕНО"
echo "════════════════════════════════════════"
echo ""
echo "📊 Статистика:"
echo "   Файлов: $(find "$TARGET_DIR" -type f | wc -l)"
echo "   Размер: $(du -sh "$TARGET_DIR" | cut -f1)"
echo ""
echo "🌐 Сайт доступен на:"
echo "   https://casino.tanukicode.one"
echo ""

