# 📋 Пошаговое руководство: Сбор API данных

На основе вашего лога консоли найдены следующие **API endpoints**:

## 🎯 Найденные API запросы

```
✅ GET /api/me
✅ GET /api/me/stats/mammoths/last
✅ GET /api/me/stats/domains/top
✅ GET /api/me/stats/deposits/range/month
✅ WS  wss://gambler-work.com/api/ws?token=...
```

## 📦 Метод 1: Автоматический сбор (РЕКОМЕНДУЕТСЯ)

### Шаг 1: Откройте оригинальный сайт
```
https://gambler-work.com
```

### Шаг 2: Откройте консоль
```
F12 → Console
```

### Шаг 3: Вставьте сборщик данных
Скопируйте весь код из файла:
```bash
cat /var/www/html/collect-api-data.js
```

Вставьте в консоль и нажмите **Enter**

### Шаг 4: Работайте с сайтом
- Кликайте по разным разделам
- Открывайте страницы статистики
- Смотрите домены
- Все запросы автоматически сохраняются!

### Шаг 5: Экспортируйте данные
В консоли выполните:
```javascript
window.exportCollectedData()
```

Скачается файл `api-data-{timestamp}.json` со всеми данными!

### Шаг 6: Создайте mock файлы
В консоли выполните:
```javascript
window.generateMockFiles()
```

Скопируйте JSON данные и создайте файлы в `/var/www/html/mock-data/`

---

## 🔧 Метод 2: Ручной сбор через DevTools

### Шаг 1: Network Tab
```
F12 → Network → Fetch/XHR
```

### Шаг 2: Обновите страницу
```
F5
```

### Шаг 3: Для каждого запроса

Например, для `/api/me`:
1. Кликните на запрос
2. Перейдите на вкладку **Response**
3. Скопируйте JSON
4. Создайте файл:

```bash
nano /var/www/html/mock-data/me.json
```

Вставьте скопированный JSON:
```json
{
  "success": true,
  "data": {
    "id": "...",
    "username": "...",
    ...
  }
}
```

### Повторите для всех endpoints:

```bash
# Пример структуры
/var/www/html/mock-data/
├── me.json
├── me_stats_mammoths_last.json
├── me_stats_domains_top.json
└── me_stats_deposits_range_month.json
```

---

## 🚀 Использование mock данных

### Вариант A: Встроенные mock (уже работает)

Текущая ULTIMATE защита уже возвращает пустые данные:
```javascript
{success: true, data: [], message: 'Offline mode'}
```

### Вариант B: Загрузка из файлов (лучше)

1. Замените файлы-примеры реальными данными:
```bash
# Уже созданы примеры:
ls -lh /var/www/html/mock-data/
```

2. Скопируйте mock-data в panel.tanukicode.one:
```bash
cp -r /var/www/html/mock-data /var/www/panel.tanukicode.one/
```

3. Добавьте enhanced-api-mock.js в HTML:
```bash
# Скопируйте код из:
cat /var/www/html/enhanced-api-mock.js
```

Добавьте перед `</body>` в `/var/www/panel.tanukicode.one/index.html`

---

## 📊 Текущий статус

### ✅ Уже готово:
- ULTIMATE защита от ошибок установлена
- Примеры mock файлов созданы:
  - `me.json` (данные пользователя)
  - `me_stats_mammoths_last.json` (последние регистрации)
  - `me_stats_domains_top.json` (топ домены)
  - `me_stats_deposits_range_month.json` (депозиты)

### 📝 Следующие шаги:
1. Запустите сборщик на оригинальном сайте
2. Экспортируйте реальные данные
3. Замените примеры в `/var/www/html/mock-data/`
4. Скопируйте в `/var/www/panel.tanukicode.one/mock-data/`
5. Проверьте на panel.tanukicode.one

---

## 🎨 Интеграция в HTML (опционально)

Если хотите полную интеграцию:

### 1. Добавьте скрипт в index.html

Создайте файл `/var/www/html/inject-mock-loader.js`:

```javascript
import fs from 'fs';
import path from 'path';

const targetDir = '/var/www/panel.tanukicode.one';
const mockScript = fs.readFileSync('/var/www/html/enhanced-api-mock.js', 'utf-8');

function addMockLoader(dir) {
  // Добавляет enhanced-api-mock.js в HTML файлы
}
```

### 2. Запустите:
```bash
node /var/www/html/inject-mock-loader.js
```

---

## 🔍 Отладка

### Проверить что mock работают:

Откройте `panel.tanukicode.one` и в консоли:
```javascript
fetch('/api/me').then(r => r.json()).then(console.log)
// Должно вернуть данные из me.json
```

### Проверить какие файлы загружены:
```bash
ls -lh /var/www/panel.tanukicode.one/mock-data/
```

---

## 📞 Быстрая справка

| Команда | Описание |
|---------|----------|
| `cat /var/www/html/collect-api-data.js` | Показать сборщик API |
| `ls /var/www/html/mock-data/` | Список mock файлов |
| `cp -r /var/www/html/mock-data /var/www/panel.tanukicode.one/` | Копировать mock данные |
| `grep -c "ULTIMATE" /var/www/panel.tanukicode.one/index.html` | Проверить защиту |

---

## ✨ Итого

1. **Сборщик готов** → `/var/www/html/collect-api-data.js`
2. **Примеры mock файлов созданы** → `/var/www/html/mock-data/`
3. **Enhanced mock loader готов** → `/var/www/html/enhanced-api-mock.js`
4. **ULTIMATE защита активна** → Ошибок нет!

**Просто соберите реальные данные и замените примеры!** 🎉

