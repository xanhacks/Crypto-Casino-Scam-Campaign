#!/bin/bash

# Копирование сайта в чистый статический HTML без React

DOMAIN=$(cat /var/www/html/domain.txt | tr -d '/' | tr -d '\n')
COOKIES=$(cat /var/www/html/cookies.txt)
OUTPUT_DIR="/var/www/html/${DOMAIN}_pure_static"

echo ""
echo "🎨 PURE STATIC COPY (без React/Next.js)"
echo "════════════════════════════════════════"
echo ""
echo "Домен: $DOMAIN"
echo "Выход: $OUTPUT_DIR"
echo ""

# Проверка wget
if ! command -v wget &> /dev/null; then
    echo "❌ wget не установлен"
    echo "Установите: apt-get install wget"
    exit 1
fi

# Удалить старую директорию
rm -rf "$OUTPUT_DIR" 2>/dev/null
mkdir -p "$OUTPUT_DIR"

# Скачать с помощью wget - рекурсивно, со всеми ресурсами
echo "📥 Скачивание сайта (чистый HTML)..."
echo ""

wget \
  --recursive \
  --level=3 \
  --no-parent \
  --page-requisites \
  --html-extension \
  --convert-links \
  --restrict-file-names=windows \
  --domains="$DOMAIN" \
  --no-clobber \
  --header="Cookie: $COOKIES" \
  --user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  --directory-prefix="$OUTPUT_DIR" \
  "https://$DOMAIN/"

if [ $? -eq 0 ]; then
  echo ""
  echo "════════════════════════════════════════"
  echo "✅ ГОТОВО"
  echo "════════════════════════════════════════"
  echo ""
  echo "📊 Статистика:"
  echo "   Файлов: $(find "$OUTPUT_DIR" -type f | wc -l)"
  echo "   Размер: $(du -sh "$OUTPUT_DIR" | cut -f1)"
  echo ""
  echo "📁 Директория: $OUTPUT_DIR"
  echo ""
  echo "⚠️  ВНИМАНИЕ:"
  echo "   Это чистый HTML без JavaScript"
  echo "   Интерактивность будет потеряна"
  echo "   Используйте для статического просмотра"
  echo ""
else
  echo ""
  echo "❌ Ошибка при скачивании"
  exit 1
fi

