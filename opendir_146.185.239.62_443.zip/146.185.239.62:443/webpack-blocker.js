import fs from 'fs';
import path from 'path';

const targetDir = process.argv[2] || '/var/www/panel.tanukicode.one';

function patchFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  let count = 0;
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    
    if (entry.isDirectory()) {
      count += patchFiles(fullPath);
    } else if (entry.name.endsWith('.html')) {
      let html = fs.readFileSync(fullPath, 'utf-8');
      
      if (html.includes('[WEBPACK-SAFE]')) {
        continue;
      }
      
      html = html.replace(/<script>[\s\S]*?(\[WEBPACK-SAFE\]|\[CLEAN\]|\[FINAL\]|\[NUCLEAR\]|\[SILENCE-V2\])[\s\S]*?<\/script>/g, '');
      
      const blocker = `<script>
(function(){
// Полное подавление ошибок
window.addEventListener('error',function(e){e.preventDefault();e.stopImmediatePropagation();return true;},true);
window.addEventListener('unhandledrejection',function(e){e.preventDefault();e.stopImmediatePropagation();},true);

// Mock API
const f=window.fetch;
window.fetch=function(...a){
  const u=a[0];
  return typeof u==='string'&&u.includes('/api/')?Promise.resolve(new Response('{"success":true,"data":[]}',{status:200})):f(...a);
};

// Перехват webpack chunk loader
setTimeout(function(){
  if(window.__webpack_chunk_load__){
    const original=window.__webpack_chunk_load__;
    window.__webpack_chunk_load__=function(chunkId){
      return Promise.resolve();
    };
  }
},0);

console.log('[WEBPACK-SAFE]');
})();
</script>`;
      
      if (html.includes('<head>')) {
        html = html.replace('<head>', '<head>' + blocker);
        fs.writeFileSync(fullPath, html);
        console.log(`✓ ${path.relative(targetDir, fullPath)}`);
        count++;
      }
    }
  }
  
  return count;
}

console.log(`\nBlocking webpack chunks...\n`);
const total = patchFiles(targetDir);
console.log(`\n✅ ${total} files\n`);

