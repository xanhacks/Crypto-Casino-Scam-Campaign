import fs from 'fs';
import path from 'path';

const targetDir = '/var/www/casino.tanukicode.one';

function patchFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  let count = 0;
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    
    if (entry.isDirectory()) {
      count += patchFiles(fullPath);
    } else if (entry.name.endsWith('.html')) {
      let html = fs.readFileSync(fullPath, 'utf-8');
      
      if (html.includes('[CLEAN]')) {
        continue;
      }
      
      const protector = `<script>
(function(){
window.addEventListener('error',function(e){e.preventDefault();e.stopImmediatePropagation();return true;},true);
window.addEventListener('unhandledrejection',function(e){e.preventDefault();e.stopImmediatePropagation();},true);
const f=window.fetch;window.fetch=function(...a){const u=a[0];return typeof u==='string'&&u.includes('/api/')?Promise.resolve(new Response('{"success":true,"data":[]}',{status:200})):f(...a);};
console.log('[CLEAN]');
})();
</script>`;
      
      if (html.includes('<head>')) {
        html = html.replace('<head>', '<head>' + protector);
        fs.writeFileSync(fullPath, html);
        console.log(`✓ ${path.relative(targetDir, fullPath)}`);
        count++;
      }
    }
  }
  
  return count;
}

console.log(`\n🛡️  Защита casino.tanukicode.one...\n`);
const total = patchFiles(targetDir);
console.log(`\n✅ ${total} files\n`);

