#!/bin/bash

# Полный цикл: скачать сайт и задеплоить

echo "=== Copy Site and Deploy ==="
echo ""

# Step 1: Run scraper
echo "[1/2] Downloading site..."
./run.sh

if [ $? -ne 0 ]; then
  echo "❌ Scraper failed"
  exit 1
fi

echo ""
echo "[2/2] Deploying to /var/www/panel.tanukicode.one..."
./deploy-auto.sh

echo ""
echo "✅ Complete!"

