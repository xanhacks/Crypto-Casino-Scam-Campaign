#!/bin/bash

# Скрипт для развертывания скачанного сайта

SOURCE_DIR="/var/www/html"
TARGET_DIR="/var/www/panel.tanukicode.one"
DOMAIN=$(cat /var/www/html/domain.txt | tr -d '\n\r' | sed 's|/$||' | sed 's|https\?://||')

echo "=== Deployment Script ==="
echo "Domain: $DOMAIN"
echo "Target: $TARGET_DIR"
echo ""

# Find latest downloaded site
LATEST_SITE=$(ls -dt ${SOURCE_DIR}/${DOMAIN}* 2>/dev/null | head -1)

if [ -z "$LATEST_SITE" ]; then
  echo "❌ Error: No downloaded site found for domain $DOMAIN"
  exit 1
fi

echo "Source: $LATEST_SITE"

# Check if files exist in nested directory
NESTED_DIR="${LATEST_SITE}/${DOMAIN}"
if [ -d "$NESTED_DIR" ]; then
  SOURCE_FILES="$NESTED_DIR"
  echo "Found files in: $SOURCE_FILES"
else
  SOURCE_FILES="$LATEST_SITE"
  echo "Found files in: $SOURCE_FILES"
fi

# Count files
FILE_COUNT=$(find "$SOURCE_FILES" -type f | wc -l)
echo "Files to deploy: $FILE_COUNT"
echo ""

# Confirm
read -p "⚠️  This will DELETE all files in $TARGET_DIR and replace them. Continue? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
  echo "❌ Cancelled"
  exit 1
fi

echo ""
echo "[1/3] Backing up old site..."
BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
if [ -d "$TARGET_DIR" ] && [ "$(ls -A $TARGET_DIR)" ]; then
  mkdir -p "$BACKUP_DIR"
  cp -r "$TARGET_DIR"/* "$BACKUP_DIR"/ 2>/dev/null || true
  echo "  ✓ Backup created: $BACKUP_DIR"
else
  echo "  ⊘ No existing files to backup"
fi

echo "[2/3] Removing old files..."
rm -rf "${TARGET_DIR}"/*
echo "  ✓ Old files removed"

echo "[3/3] Deploying new files..."
cp -r "$SOURCE_FILES"/* "$TARGET_DIR"/
echo "  ✓ Files copied"

# Set permissions
chown -R www-data:www-data "$TARGET_DIR" 2>/dev/null || true
chmod -R 755 "$TARGET_DIR" 2>/dev/null || true

echo ""
echo "=== Deployment Complete ==="
echo "Files deployed: $(find $TARGET_DIR -type f | wc -l)"
echo "Location: $TARGET_DIR"
echo "Backup: $BACKUP_DIR"
echo ""
echo "✅ Site is now live at: http://panel.tanukicode.one"

