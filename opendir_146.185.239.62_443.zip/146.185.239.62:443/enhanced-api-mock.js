// Enhanced API Mock - использует реальные mock файлы
// Добавьте этот скрипт в HTML ПОСЛЕ всех других скриптов

(function() {
  'use strict';
  
  // База для mock данных
  const MOCK_BASE = '/mock-data';
  
  // Маппинг endpoint -> файл
  const endpointToFile = {
    '/api/me': 'me.json',
    '/api/me/stats/mammoths/last': 'me_stats_mammoths_last.json',
    '/api/me/stats/domains/top': 'me_stats_domains_top.json',
    '/api/me/stats/deposits/range/month': 'me_stats_deposits_range_month.json'
  };
  
  // Кэш для загруженных данных
  const mockCache = {};
  
  // Загрузка mock данных
  async function loadMockData(endpoint) {
    // Убираем query параметры
    const cleanEndpoint = endpoint.split('?')[0];
    
    // Проверяем кэш
    if (mockCache[cleanEndpoint]) {
      return mockCache[cleanEndpoint];
    }
    
    // Ищем файл
    const filename = endpointToFile[cleanEndpoint];
    if (!filename) {
      console.warn('[MOCK] No mock file for:', cleanEndpoint);
      return { success: true, data: null };
    }
    
    try {
      const response = await fetch(`${MOCK_BASE}/${filename}`);
      const data = await response.json();
      mockCache[cleanEndpoint] = data;
      console.log(`[MOCK] Loaded ${filename} for ${cleanEndpoint}`);
      return data;
    } catch (e) {
      console.error('[MOCK] Failed to load:', filename, e);
      return { success: false, error: 'Mock data not found' };
    }
  }
  
  // Перехват fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = args[0];
    
    if (typeof url === 'string' && url.includes('/api/')) {
      const endpoint = url.replace(window.location.origin, '');
      const mockData = await loadMockData(endpoint);
      
      console.log('[MOCK API]', endpoint, mockData);
      
      return Promise.resolve(new Response(JSON.stringify(mockData), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      }));
    }
    
    return originalFetch.apply(this, args);
  };
  
  console.log('[ENHANCED MOCK] Active with real mock data files');
})();

