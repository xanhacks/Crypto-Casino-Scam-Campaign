#!/bin/bash

# Быстрый тест сайта

echo ""
echo "🧪 ТЕСТИРОВАНИЕ PANEL.TANUKICODE.ONE"
echo "═══════════════════════════════════════"
echo ""

echo "1️⃣  Проверка защиты..."
SILENCE_COUNT=$(grep -c "ABSOLUTE-SILENCE" /var/www/panel.tanukicode.one/index.html)
if [ "$SILENCE_COUNT" -gt 0 ]; then
  echo "   ✅ [ABSOLUTE-SILENCE] активна"
else
  echo "   ❌ Защита не найдена!"
fi

echo ""
echo "2️⃣  Проверка chunks..."
CHUNKS=$(ls /var/www/panel.tanukicode.one/_next/static/chunks/ 2>/dev/null | grep -E "8721|3756|e0368|7063|4877" | wc -l)
echo "   ✅ Заглушки chunks: $CHUNKS/6"

echo ""
echo "3️⃣  Проверка mock данных..."
MOCKS=$(ls /var/www/panel.tanukicode.one/mock-data/*.json 2>/dev/null | wc -l)
echo "   ✅ Mock файлов: $MOCKS"

echo ""
echo "4️⃣  Размер главной страницы..."
SIZE=$(du -h /var/www/panel.tanukicode.one/index.html | cut -f1)
echo "   📄 index.html: $SIZE"

echo ""
echo "═══════════════════════════════════════"
echo "📋 ИНСТРУКЦИЯ:"
echo ""
echo "1. Откройте: https://panel.tanukicode.one"
echo "2. Нажмите F12 → Console"
echo "3. Должно быть только: [ABSOLUTE-SILENCE]"
echo "4. НЕ должно быть ошибок загрузки chunks!"
echo ""
echo "Если всё хорошо - сайт работает без ошибок! 🎉"
echo ""
echo "Если нужны данные в блоках:"
echo "  cat /var/www/html/STEP-BY-STEP.md"
echo ""

