import scrape from 'website-scraper';
import PuppeteerPlugin from 'website-scraper-puppeteer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Read domain from domain.txt
let domainInput = fs.readFileSync('domain.txt', 'utf-8').trim();
domainInput = domainInput.replace(/^https?:\/\//, '').replace(/\/$/, ''); // Remove protocol and trailing slash
console.log(`Loaded domain input: ${domainInput}`);

// Extract base domain and start path
const [baseDomain, ...pathParts] = domainInput.split('/');
const startPath = pathParts.length > 0 ? '/' + pathParts.join('/') : '';
const domain = baseDomain;
console.log(`Base domain: ${domain}`);
console.log(`Start path: ${startPath || '/'}`);
const startUrl = `https://${domainInput}`;
console.log(`Start URL: ${startUrl}`);

// Find available directory name
let outputDir = path.resolve(__dirname, domain);
let counter = 1;
while (fs.existsSync(outputDir)) {
  outputDir = path.resolve(__dirname, `${domain}_${counter}`);
  counter++;
}
console.log(`Output directory: ${outputDir}`);

// Read cookies from cookies.txt (format: key1=value1;key2=value2)
const cookiesString = fs.readFileSync('cookies.txt', 'utf-8').trim();
console.log(`Loaded cookies (${cookiesString.length} characters)`);

// Parse cookies into array of objects - try both domain formats
const cookiesBase = cookiesString.split(';').map(cookie => {
  const [name, value] = cookie.trim().split('=');
  return { name, value };
});

const cookies = [];
cookiesBase.forEach(({ name, value }) => {
  // Add cookie with domain (works for all subdomains)
  cookies.push({
    name, value,
    domain: `.${domain}`,
    path: '/',
    secure: true,
    httpOnly: false,
    sameSite: 'None'
  });
  // Also add cookie for exact domain
  cookies.push({
    name, value,
    domain: domain,
    path: '/',
    secure: true,
    httpOnly: false,
    sameSite: 'None'
  });
});

console.log(`Parsed ${cookiesBase.length} cookies (with domain variants: ${cookies.length})`);

// Configuration for the scraper
const options = {
  urls: [startUrl], // Starting URL
  directory: outputDir,
  recursive: true, // Follow all internal links
  maxRecursiveDepth: 10, // Maximum depth to prevent infinite loops
  maxDepth: 10,
  requestConcurrency: 3, // Download 3 resources in parallel
  
  urlFilter: (url) => {
    try {
      const urlObj = new URL(url);
      const isSameDomain = urlObj.hostname === domain;
      
      // Skip external, mailto, tel, javascript
      if (!isSameDomain) return false;
      if (url.includes('mailto:')) return false;
      if (url.includes('tel:')) return false;
      if (url.includes('javascript:')) return false;
      
      return true;
    } catch (err) {
      return false;
    }
  },
  request: {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Cookie': cookiesString // Also set as header
    }
  },
  filenameGenerator: 'bySiteStructure', // Save files exactly as on original site
  prettifyUrls: false, // Keep original URLs
  ignoreErrors: false, // Stop on errors to debug
  
  // Resources to download
  sources: [
    { selector: 'a[href]', attr: 'href' },
    { selector: 'img', attr: 'src' },
    { selector: 'img', attr: 'srcset' },
    { selector: 'link[rel="stylesheet"]', attr: 'href' },
    { selector: 'script', attr: 'src' },
    { selector: 'link[rel*="icon"]', attr: 'href' },
    { selector: 'link[as="font"]', attr: 'href' },
    { selector: 'link[as="image"]', attr: 'href' },
    { selector: 'link[as="script"]', attr: 'href' },
    { selector: 'link[rel="preload"]', attr: 'href' },
    { selector: 'video', attr: 'src' },
    { selector: 'video', attr: 'poster' },
    { selector: 'source', attr: 'src' },
    { selector: 'audio', attr: 'src' },
    { selector: 'object', attr: 'data' },
    { selector: 'embed', attr: 'src' }
  ],
  plugins: [
    {
      apply: async (registerAction) => {
        let browser;
        let page;
        
        registerAction('beforeStart', async () => {
          console.log('[PLUGIN] Initializing...');
        });
        
        registerAction('afterResponse', async ({ response }) => {
          console.log(`[DOWNLOAD] ${response.url}`);
        });
      }
    },
    new PuppeteerPlugin({
      launchOptions: { 
        headless: 'new',
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage'
        ]
      },
      blockNavigation: false,
      scrollToBottom: { timeout: 10000, viewportN: 10 },
      gotoOptions: {
        waitUntil: 'networkidle2',
        timeout: 60000
      },
      beforeRequest: async ({ page, requestOptions }) => {
        console.log(`\n[PUPPETEER] Loading page...`);
        
        // Set cookies
        try {
          await page.setCookie(...cookies);
          console.log(`[COOKIES] Set ${cookies.length} cookies`);
        } catch (err) {
          console.error(`[COOKIES ERROR] ${err.message}`);
        }
      }
    })
  ]
};


// Add logging hooks
let savedCount = 0;
let htmlPages = [];
let cssFiles = [];
let jsFiles = [];
let imageFiles = [];
let fontFiles = [];
let otherFiles = [];

const downloadedFiles = new Set();

options.onResourceSaved = (resource) => {
  savedCount++;
  const url = resource.url || '';
  const filename = resource.filename || '';
  
  // Skip duplicates
  if (downloadedFiles.has(url)) {
    return;
  }
  downloadedFiles.add(url);
  
  // Better type detection
  let resourceType = 'unknown';
  if (resource.type) {
    resourceType = resource.type;
  } else if (url.match(/\.css(\?|$)/i)) {
    resourceType = 'css';
  } else if (url.match(/\.js(\?|$)/i)) {
    resourceType = 'script';
  } else if (url.match(/\.(jpg|jpeg|png|gif|svg|webp)(\?|$)/i)) {
    resourceType = 'image';
  } else if (url.match(/\.(woff|woff2|ttf|eot)(\?|$)/i)) {
    resourceType = 'font';
  } else if (filename.endsWith('.html') || filename.endsWith('/index.html') || url.endsWith('/') || !url.match(/\.[a-z]{2,4}$/i)) {
    resourceType = 'html';
  }
  
  // Categorize and count
  if (resourceType === 'html') {
    htmlPages.push(resource);
    console.log(`\n[PAGE ${htmlPages.length}] ${url}`);
    
    // Show internal links on this page
    if (resource.children) {
      const links = resource.children.filter(c => {
        const u = c.url || '';
        return !u.match(/\.(css|js|jpg|jpeg|png|gif|svg|webp|woff|woff2|ttf|eot|ico)$/i);
      });
      if (links.length > 0) {
        console.log(`  → Will crawl ${links.length} internal pages`);
      }
    }
  } else if (resourceType === 'css') {
    cssFiles.push(resource);
  } else if (resourceType === 'script') {
    jsFiles.push(resource);
  } else if (resourceType === 'image') {
    imageFiles.push(resource);
  } else if (resourceType === 'font') {
    fontFiles.push(resource);
  } else {
    otherFiles.push(resource);
  }
  
  // Update progress
  process.stdout.write(`\r[Progress] Pages: ${htmlPages.length}, CSS: ${cssFiles.length}, JS: ${jsFiles.length}, Images: ${imageFiles.length}, Fonts: ${fontFiles.length}, Total: ${savedCount}`);
};

options.onResourceError = (resource, err) => {
  console.error(`\n[ERROR] ${resource.url}`);
  console.error(`  Message: ${err.message}`);
};

// Run the scraper
(async () => {
  try {
    console.log('Starting site scraping...');
    console.log(`Target: https://${domain}`);
    console.log(`Output: ${outputDir}`);
    console.log(`Cookies: ${cookiesBase.length} (${cookiesBase.map(c => c.name).join(', ')})`);
    console.log(`Recursive: ENABLED (max depth: 10)\n`);

    console.log('[DEBUG] Starting scraper...\n');
    const result = await scrape(options);
    console.log('\n[DEBUG] Scraper finished\n');
    
    // Post-process ALL HTML files
    console.log('\n[POST-PROCESS] Adding error handling to HTML files...');
    const allHtmlFiles = [];
    
    // Find all HTML files in output directory
    function findHtmlFiles(dir) {
      const files = fs.readdirSync(dir, { withFileTypes: true });
      for (const file of files) {
        const fullPath = path.join(dir, file.name);
        if (file.isDirectory()) {
          findHtmlFiles(fullPath);
        } else if (file.name.endsWith('.html')) {
          allHtmlFiles.push(fullPath);
        }
      }
    }
    
    findHtmlFiles(outputDir);
    console.log(`Found ${allHtmlFiles.length} HTML files to process`);
    
    // Webpack-safe protector
    const protector = `<script>
(function(){
window.addEventListener('error',function(e){e.preventDefault();e.stopImmediatePropagation();return true;},true);
window.addEventListener('unhandledrejection',function(e){e.preventDefault();e.stopImmediatePropagation();},true);
const f=window.fetch;
window.fetch=function(...a){const u=a[0];return typeof u==='string'&&u.includes('/api/')?Promise.resolve(new Response('{"success":true,"data":[]}',{status:200})):f(...a);};
setTimeout(function(){if(window.__webpack_chunk_load__){const o=window.__webpack_chunk_load__;window.__webpack_chunk_load__=function(c){return Promise.resolve();};}},0);
console.log('[WEBPACK-SAFE]');
})();
</script>`;
    
    for (const filepath of allHtmlFiles) {
      let html = fs.readFileSync(filepath, 'utf-8');
      
      if (html.includes('[WEBPACK-SAFE]')) {
        continue;
      }
      
      html = html.replace(/<script>[\s\S]*?(\[WEBPACK-SAFE\]|\[CLEAN\]|\[FINAL\]|\[NUCLEAR\]|\[SILENCE-V2\]|\[PROTECTED\]|\[CHUNK-SAFE\]|\[ULTIMATE\]|\[SUPER-SILENT\]|\[ABSOLUTE-SILENCE\])[\s\S]*?<\/script>/g, '');
      
      if (html.includes('<head>')) {
        html = html.replace('<head>', '<head>' + protector);
        fs.writeFileSync(filepath, html);
      }
    }
    
    console.log(`[POST-PROCESS] ✅ Processed ${allHtmlFiles.length} HTML files`);
    
    console.log('=== Site copied successfully ===');
    console.log(`Total files downloaded: ${result.length}`);
    console.log(`  - HTML pages: ${htmlPages.length}`);
    console.log(`  - CSS files: ${cssFiles.length}`);
    console.log(`  - JS files: ${jsFiles.length}`);
    console.log(`  - Images: ${imageFiles.length}`);
    console.log(`  - Fonts: ${fontFiles.length}`);
    console.log(`  - Other: ${otherFiles.length}`);
    
    console.log('\n=== Downloaded HTML Pages ===');
    htmlPages.forEach((page, index) => {
      console.log(`${index + 1}. ${page.url}`);
    });
    
    // Check if cookies worked
    const hasRootPage = htmlPages.some(p => p.url === `https://${domain}/` || p.url === `https://${domain}/index.html` || p.url === `https://${domain}`);
    const hasLandPage = htmlPages.some(p => p.url.includes('/land'));
    const hasAuthPage = htmlPages.some(p => p.url.includes('/auth') || p.url.includes('/login'));
    
    console.log('\n=== Cookie Authentication Check ===');
    console.log(`Root page: ${hasRootPage ? 'YES ✅' : 'NO ❌'}`);
    console.log(`Landing page (/land): ${hasLandPage ? 'YES' : 'NO'}`);
    console.log(`Auth/Login page: ${hasAuthPage ? 'YES ❌' : 'NO ✅'}`);
    
    if (hasAuthPage) {
      console.log('\n❌ COOKIES NOT WORKING - Site redirected to auth page');
      console.log('💡 Check: cookie domain, expiration, or token validity');
    } else if (hasRootPage && !hasLandPage) {
      console.log('\n✅ COOKIES WORKING - Downloaded authenticated pages');
    } else if (hasLandPage && !hasRootPage) {
      console.log('\n⚠️  PARTIAL - Downloaded landing page (cookies may not be working)');
    }
    
    if (cssFiles.length > 0) {
      console.log('\n=== CSS Files ===');
      cssFiles.slice(0, 10).forEach((f, i) => console.log(`${i + 1}. ${f.filename}`));
      if (cssFiles.length > 10) console.log(`... and ${cssFiles.length - 10} more CSS files`);
    }
    
    if (jsFiles.length > 0) {
      console.log('\n=== JavaScript Files ===');
      jsFiles.slice(0, 10).forEach((f, i) => console.log(`${i + 1}. ${f.filename}`));
      if (jsFiles.length > 10) console.log(`... and ${jsFiles.length - 10} more JS files`);
    }
    
    if (imageFiles.length > 0) {
      console.log('\n=== Images ===');
      imageFiles.slice(0, 10).forEach((f, i) => console.log(`${i + 1}. ${f.filename}`));
      if (imageFiles.length > 10) console.log(`... and ${imageFiles.length - 10} more images`);
    }
    
    if (fontFiles.length > 0) {
      console.log('\n=== Fonts ===');
      fontFiles.forEach((f, i) => console.log(`${i + 1}. ${f.filename}`));
    }
    
    console.log('');
  } catch (err) {
    console.error('Error copying site:', err);
  } finally {
    console.log('Scraping completed.');
  }
})();
