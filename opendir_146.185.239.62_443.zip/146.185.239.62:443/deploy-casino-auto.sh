#!/bin/bash

TARGET_DIR="/var/www/casino.tanukicode.one"
SOURCE_BASE="/var/www/html"

LATEST_DIR=$(find "$SOURCE_BASE" -maxdepth 1 -type d -name "*.com*" 2>/dev/null | sort -r | head -1)

if [ -z "$LATEST_DIR" ]; then
  echo "❌ Не найдена скачанная директория!"
  exit 1
fi

CONTENT_DIR=$(find "$LATEST_DIR" -mindepth 1 -maxdepth 1 -type d | head -1)

if [ -z "$CONTENT_DIR" ]; then
  echo "❌ Пустая директория"
  exit 1
fi

# Backup
if [ -d "$TARGET_DIR" ] && [ "$(ls -A $TARGET_DIR 2>/dev/null)" ]; then
  BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
  cp -r "$TARGET_DIR" "$BACKUP_DIR" 2>/dev/null
fi

# Deploy
rm -rf "$TARGET_DIR"/* 2>/dev/null
mkdir -p "$TARGET_DIR"
cp -r "$CONTENT_DIR"/* "$TARGET_DIR"/
chown -R www-data:www-data "$TARGET_DIR" 2>/dev/null || chown -R root:root "$TARGET_DIR"
chmod -R 755 "$TARGET_DIR"

echo "✅ Развернуто: $(find "$TARGET_DIR" -type f | wc -l) файлов"
echo "🌐 https://casino.tanukicode.one"

