import puppeteer from 'puppeteer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import https from 'https';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const domain = fs.readFileSync(path.join(__dirname, 'domain.txt'), 'utf-8').trim().replace(/\/$/, '');
const cookiesString = fs.readFileSync(path.join(__dirname, 'cookies.txt'), 'utf-8').trim();

const cookiesBase = cookiesString.split(';').map(cookie => {
  const [name, value] = cookie.trim().split('=');
  return { name, value, domain: domain };
});

const outputDir = path.join(__dirname, `${domain}_rendered`);

console.log('🎨 RENDERED STATIC COPY\n');
console.log(`Домен: ${domain}`);
console.log(`Cookies: ${cookiesBase.length}\n`);

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

async function downloadResource(url, savePath) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'Cookie': cookiesString,
        'User-Agent': 'Mozilla/5.0'
      }
    };
    
    https.get(url, options, (res) => {
      if (res.statusCode !== 200) {
        resolve(false);
        return;
      }
      
      const dir = path.dirname(savePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      const file = fs.createWriteStream(savePath);
      res.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve(true);
      });
    }).on('error', () => resolve(false));
  });
}

async function copyRendered() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setCookie(...cookiesBase);
  
  console.log('📄 Загрузка и рендеринг страницы...\n');
  
  await page.goto(`https://${domain}`, {
    waitUntil: 'networkidle0',
    timeout: 60000
  });
  
  // Ждем полного рендеринга React
  await page.waitForTimeout(5000);
  
  console.log('🎨 Обработка DOM...\n');
  
  // Получить все ресурсы
  const resources = await page.evaluate(() => {
    const res = {
      css: [],
      images: [],
      fonts: []
    };
    
    // CSS
    document.querySelectorAll('link[rel="stylesheet"]').forEach(link => {
      res.css.push(link.href);
    });
    
    // Images
    document.querySelectorAll('img[src]').forEach(img => {
      res.images.push(img.src);
    });
    
    // Background images
    document.querySelectorAll('*').forEach(el => {
      const bg = window.getComputedStyle(el).backgroundImage;
      if (bg && bg !== 'none') {
        const match = bg.match(/url\("?([^"]+)"?\)/);
        if (match) res.images.push(match[1]);
      }
    });
    
    return res;
  });
  
  console.log(`Найдено:`);
  console.log(`  CSS: ${resources.css.length}`);
  console.log(`  Images: ${resources.images.length}\n`);
  
  // Скачать CSS
  for (const url of resources.css) {
    const filename = url.replace(/^https?:\/\/[^/]+\//, '');
    const savePath = path.join(outputDir, filename);
    await downloadResource(url, savePath);
  }
  
  // Скачать изображения (первые 50)
  const imagesToDownload = [...new Set(resources.images)].slice(0, 50);
  for (const url of imagesToDownload) {
    if (!url.startsWith('data:')) {
      const filename = url.replace(/^https?:\/\/[^/]+\//, '');
      const savePath = path.join(outputDir, filename);
      await downloadResource(url, savePath);
    }
  }
  
  // Получить финальный HTML
  const html = await page.evaluate(() => {
    // Удалить все script теги
    document.querySelectorAll('script').forEach(el => el.remove());
    
    // Удалить React атрибуты
    document.querySelectorAll('*').forEach(el => {
      Array.from(el.attributes).forEach(attr => {
        if (attr.name.startsWith('data-react') || attr.name.startsWith('data-next')) {
          el.removeAttribute(attr.name);
        }
      });
    });
    
    return '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
  });
  
  fs.writeFileSync(path.join(outputDir, 'index.html'), html);
  console.log(`\n✅ Сохранено: index.html (${(html.length/1024).toFixed(1)} KB)`);
  
  await browser.close();
}

copyRendered()
  .then(() => {
    console.log('\n════════════════════════════════════════');
    console.log('✅ ГОТОВО');
    console.log('════════════════════════════════════════\n');
    console.log(`📁 ${outputDir}`);
    console.log(`📊 Файлов: $(find "${outputDir}" -type f | wc -l)`);
    console.log('\n⚠️  Это статический HTML без JavaScript');
    console.log('   Интерактивность потеряна\n');
  })
  .catch(err => {
    console.error('\n❌ Ошибка:', err.message);
    process.exit(1);
  });

