import aiohttp
import asyncio
import json
import logging
from config import *



async def get_promo(promo_name: str):
    url = f"https://gambler-partners.is/api/me/promo/{promo_name}"
    headers = {
        "Authorization": API_TOKEN
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def create_promo(data: dict):
    url = "https://gambler-partners.is/api/me/promo"
    headers = {
        "Authorization": API_TOKEN,  
        "Content-Type": "application/json"
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=data) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def edit_promo(data: dict):
    url = "https://gambler-partners.is/api/me/promo"
    headers = {
        "Authorization": API_TOKEN,  
        "Content-Type": "application/json"
    }

    async with aiohttp.ClientSession() as session:
        async with session.patch(url, headers=headers, json=data) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def get_promo_stats(promo_name: str):
    url = f"https://gambler-partners.is/api/me/stats/promo/{promo_name}"
    headers = {
        "Authorization": API_TOKEN,
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def delete_promo(promo_name: str):
    url = "https://gambler-partners.is/api/me/promo"
    headers = {
        "Authorization": API_TOKEN,
        "Content-Type": "application/json"
    }

    async with aiohttp.ClientSession() as session:
        async with session.delete(url, headers=headers, json={"name": promo_name}) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def get_profile_stats():
    url = "https://gambler-partners.is/api/me/stats/global?time=all"
    headers = {
        "Authorization": API_TOKEN
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            else:
                return "Ошибка:", response.status, await response.text()


async def test_deposit():
    url = "https://gambler-partners.is/api/me/deposits/test?mammothId=7384510250977592821&amount=500&promo=elno100&token=bnb_bep20"
    headers = {
        "Authorization": API_TOKEN
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            print('res', await response.text())
            if response.status == 200:

                return True

            else:
                return "Ошибка:", response.status, await response.text()


BASE_URL = "https://gambler-partners.is/api/me"

async def _request(method: str, endpoint: str, params: dict = None, json_data: dict = None, data: dict = None):
    url = f"{BASE_URL}{endpoint}"
    headers = {"Authorization": API_TOKEN}
    if json_data or (data and not isinstance(data, aiohttp.FormData)):
        headers["Content-Type"] = "application/json"

    logger.info(f"API ЗАПРОС: Метод={method}, URL={url}, Параметры={params}, Тело={json_data or data}")

    async with aiohttp.ClientSession() as session:
        async with session.request(method, url, headers=headers, params=params, json=json_data, data=data) as response:


            raw_response_text = await response.text()
            logger.info(f"СЫРОЙ ОТВЕТ API: URL={url}, Статус={response.status}, Тело={raw_response_text}")


            response_body = None
            try:

                if 'application/json' in response.headers.get('Content-Type', ''):
                    response_body = json.loads(raw_response_text)
                else:
                    response_body = raw_response_text
            except Exception as e:
                logger.error(f"Ошибка парсинга JSON из ответа: {e}")
                response_body = raw_response_text

            if 200 <= response.status < 300:
                if response.status == 204:
                    return {"success": True, "status_code": response.status, "data": None}
                return {"success": True, "status_code": response.status, "data": response_body}
            else:
                return {"success": False, "status_code": response.status, "error_body": response_body, "data": None}

async def list_user_domains():
    return await _request("GET", "/domains")

async def add_user_domain(domain_name: str):
    return await _request("POST", "/domains", json_data={"domain": domain_name})

async def verify_user_domain(domain_name: str):
    return await _request("POST", "/domains/verify", json_data={"domain": domain_name})

async def delete_user_domain(domain_name: str):
    return await _request("DELETE", "/domains", json_data={"domain": domain_name})

async def get_domain_ns(domain_name: str):
    domains = await list_user_domains()
    if not domains.get("success"):
        return None
    for d in domains.get("data", {}).get("data", []):
        if d.get("name") == domain_name:
            return d.get("nameservers", [])
    return None

async def set_domain_template(domain, template):
    params = {
        "domain": domain,
        "template": template
    }
    return await _request("POST", "/domains/template", json_data=params)

async def set_geoblock(domain, countries):
    params = {
        "domain": domain,
        "countries": countries
    }
    return await _request("POST", "/domains/geoblock", json_data=params)
