import logging
from colorama import Fore, Style, init
init(autoreset=True)
def create_logger(__name__):

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler("app.log", encoding='utf-8'),
        ],
        encoding='utf-8'
    )

    return logging.getLogger(__name__)
