import sqlite3
from aiogram import types
import os
from log import create_logger
from config import db_DIR, bot
logger = create_logger(__name__)
if not os.path.isdir(db_DIR):
    os.mkdir(db_DIR)
conn = sqlite3.connect(db_DIR + "db.db", check_same_thread=False)
cursor = conn.cursor()


class DB:


    users_table = "users"
    unconfirmed_users_table = "unconfirmed_users"
    bot_info = "bot_info"
    promocodes = "promocodes"
    deposits = "deposits"
    branches_table = "branches"

    def run():
        """
        Создание таблиц БД
        """

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id                      INTEGER PRIMARY KEY,
                user_id                 INTEGER NOT NULL,
                tg_username             TEXT,
                tg_firstname            TEXT,
                username                TEXT,
                balance                 REAL NOT NULL,
                all_time_balance        REAL NOT NULL,
                cash_circulation        REAL,
                percentage              INTEGER,
                percentage_edit_type    TEXT,
                btc_wallet              TEXT,
                usdt_wallet             TEXT,
                _is_banned              TEXT
                
            )
        ''')
        conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS unconfirmed_users (
                id             INTEGER PRIMARY KEY,
                user_id        INTEGER NOT NULL,
                tg_username    TEXT,
                state          TEXT NOT NULL,
                experience     TEXT NOT NULL,
                forum_url      TEXT NOT NULL
            )
        ''')
        conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bot_info (
                id             INTEGER PRIMARY KEY,
                actual_url        TEXT,
                info              TEXT,
                all_time_balance  REAL,
                promo_activations INTEGER,
                deposits          INTEGER
            )
        ''')
        conn.commit()


        cursor.execute("SELECT actual_url, info FROM bot_info")
        exists = cursor.fetchall()
        if not exists:
            cursor.execute('INSERT INTO bot_info (actual_url, info, all_time_balance, promo_activations, deposits) VALUES (?, ?, ?, ?, ?)', ("REPLACE_ME", "REPLACE_ME", 0, 0, 0))
            conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS promocodes (
                id                  INTEGER PRIMARY KEY,
                name                TEXT NOT NULL,
                user_id             INTEGER NOT NULL,
                amount              INTEGER NOT NULL,
                activation_count    INTEFER NOT NULL,
                deposit             INTEGER NOT NULL,
                ubt                 TEXT NOT NULL   
            )
        ''')
        conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS deposits (
                id                  INTEGER PRIMARY KEY,
                worker_id           INTEGER NOT NULL,
                amount              REAL NOT NULL,
                amountUSD           REAL NOT NULL,       
                mamonth_login       TEXT NOT NULL,
                token               TEXT NOT NULL,
                domain              TEXT NOT NULL,
                date                TEXT NOT NULL,
                hash                TEXT NOT NULL,
                country             TEXT NOT NULL
            )
        ''')
        conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS branches (
                id                  INTEGER PRIMARY KEY,
                owner_id            INTEGER NOT NULL,
                name                TEXT NOT NULL,
                percentage          INTEGER NOT NULL
            )
        ''')
        conn.commit()


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_domains (
                id                  INTEGER PRIMARY KEY,
                user_id             INTEGER NOT NULL,
                domain_name         TEXT NOT NULL,
                status              TEXT NOT NULL,
                added_date          TEXT NOT NULL
            )
        ''')
        conn.commit()


        try:
            cursor.execute("ALTER TABLE users ADD COLUMN branch_id INTEGER")
            conn.commit()
        except sqlite3.OperationalError:
            pass


    def insert_new_user(user_id: int, tg_username: str, forum_url: str, exp: str):
        cursor.execute(
            'INSERT INTO unconfirmed_users (user_id, tg_username, state, forum_url, experience) '
            'VALUES (?, ?, ?, ?, ?)',
            (user_id, tg_username, "wait", forum_url, exp))
        conn.commit()


    def insert(user_id: int, tg_username: str, tg_firstname: str):
        is_user = DB.get(user_id=user_id, data="user_id", table=DB.users_table)
        if is_user is None:
            cursor.execute(
                'INSERT INTO users (user_id, tg_username, tg_firstname, balance, all_time_balance, percentage, percentage_edit_type, username, btc_wallet, usdt_wallet, _is_banned, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (user_id, tg_username, tg_firstname, 0, 0, 50, 'auto', tg_username, None, None, 'False', None))
            conn.commit()
        else:
            pass

    def insert_promo(user_id: int, name: str, ubt: str, amount: int):
        cursor.execute(
            'INSERT INTO promocodes (user_id, name, amount, ubt, activation_count, deposit) '
            'VALUES (?, ?, ?, ?, ?, ?)',
            (user_id, name, amount, ubt, 0, 0))
        conn.commit()

    def insert_branch(owner_id: int, name: str, percentage: int):

        cursor.execute(
            'INSERT INTO branches (owner_id, name, percentage) '
            'VALUES (?, ?, ?)',
            (owner_id, name, percentage))
        conn.commit()


    def get(user_id: int, data: str, table: str):
        
        cursor.execute(
            f"SELECT {data} FROM {table} WHERE user_id = ?",
            (user_id, ))
        
        result = cursor.fetchone()
        if result is not None:
            return result[0]
        else:
            return None
    
    def get_without_user_id(data: str, table: str):
        
        cursor.execute(f"SELECT {data} FROM {table}")
        result = cursor.fetchone()
        if result is not None:
            return result[0]
        else:
            return None
        
    
    def get_all_user_id(user_id: int, data: str, table: str):
        
        cursor.execute(f"SELECT {data} FROM {table} WHERE user_id = ?", (user_id, ))
        fetch = cursor.fetchall()
        result = []
        for item in fetch:
            item = item[0]
            result.append(item)
        return result
    
    def get_all(data: str, table: str):
        cursor.execute(f"SELECT {data} FROM {table}")
        fetch = cursor.fetchall()
        result = []
        for item in fetch:
            item = item[0]
            result.append(item)
        return result

    def delete(user_id: int, table: str):
        
        try:
            cursor.execute(f"DELETE from {table} where user_id = ?", (user_id,))
            conn.commit()
            return True
        except Exception:
            return False

    def update(user_id: int, column: str, new_data: str, table: str):
        
        try:
            cursor.execute(f"UPDATE {table} SET {column} = ? WHERE user_id = ?", (new_data, user_id))
            conn.commit()
            return True
        except Exception:
            return False
    
    def update_without_user_id(column: str, new_data: str, table: str):
        
        try:
            cursor.execute(f"UPDATE {table} SET {column} = ?", (new_data, ))
            conn.commit()
            return True
        except Exception as e:
            logger.error(e)

    def add_user_domain(user_id: int, domain_name: str, status: str):
        from datetime import datetime
        added_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute(
            'INSERT INTO user_domains (user_id, domain_name, status, added_date) VALUES (?, ?, ?, ?)',
            (user_id, domain_name, status, added_date))
        conn.commit()

    def get_user_domains(user_id: int):
        cursor.execute("SELECT id, domain_name, status, added_date FROM user_domains WHERE user_id = ?", (user_id,))
        return cursor.fetchall()

    def get_domain_by_id(domain_id: int, user_id: int):
        cursor.execute("SELECT id, user_id, domain_name, status, added_date FROM user_domains WHERE id = ? AND user_id = ?", (domain_id, user_id))
        result = cursor.fetchone()
        if result:
            return {
                'id': result[0],
                'user_id': result[1],
                'domain_name': result[2],
                'status': result[3],
                'added_date': result[4]
            }
        return None

    def update_user_domain_status(domain_id: int, new_status: str, user_id: int):
        cursor.execute("UPDATE user_domains SET status = ? WHERE id = ? AND user_id = ?", (new_status, domain_id, user_id))
        conn.commit()
