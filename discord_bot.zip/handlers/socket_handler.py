import json
import logging
import os
import sys
import threading
import time
import websocket
import urllib.parse
from queue import Queue
import threading

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import config
import utils

token = urllib.parse.quote(f"Worker {config.API_TOKEN}")
died_timeout = None

msg_queue = Queue()
msg_processing = False
msg_lock = threading.Lock()

deposit_queue = Queue()
deposit_processing = False
deposit_lock = threading.Lock()

def on_message(ws, message):
    global died_timeout
    try:
        data = json.loads(message)
        if data.get("name") == "ping":
            if died_timeout:
                died_timeout.cancel()
            died_timeout = threading.Timer(10, ws.close)
            ws.send(json.dumps({"name": "pong"}))
        else:
            if data.get("name") == "newDeposit":
                logging.info("New deposit!")

                deposit_queue.put(data["data"])
                process_deposits()
            elif data.get("name") == "newMessage":
                logging.info("New message!")

                msg_queue.put(data["data"])
                process_msg()                
            
    except Exception:
        pass

def process_msg():
    global msg_processing
    

    with msg_lock:
        if msg_processing:
            return
        msg_processing = True
    
    try:
        while not msg_queue.empty():
            current_msg = msg_queue.get()
            try:
                utils.send_newMessage(current_msg)
            except AttributeError:
                return
            except Exception as e:
                logging.error(f"Error processing msg: {e}")
            finally:
                msg_queue.task_done()
    finally:
        with msg_lock:
            msg_processing = False



def process_deposits():
    global deposit_processing
    

    with deposit_lock:
        if deposit_processing:
            return
        deposit_processing = True
    
    try:
        while not deposit_queue.empty():
            current_deposit = deposit_queue.get()
            try:
                utils.send_newDeposit(current_deposit)
            except Exception as e:
                logging.error(f"Error processing deposit: {e}")
            finally:
                deposit_queue.task_done()
    finally:
        with deposit_lock:
            deposit_processing = False

def on_close(ws):
    print("LCLOSE")

def connect_to_ws():
    global died_timeout
    died_timeout = None
    ws = websocket.WebSocketApp(f"wss://gambler-partners.is/api/ws?token={token}&connectionType=bot",
                                on_message=on_message)
    ws.run_forever()

def run():
    while True:
        try:
            connect_to_ws()
        except KeyboardInterrupt:
            quit()
        except Exception:
            time.sleep(5)

if __name__ == "__main__":
    run()
