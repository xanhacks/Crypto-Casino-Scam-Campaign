import json
import re

from api import get_promo
from config import *
import utils
from db import DB, cursor, conn
import api
from log import create_logger
logger = create_logger(__name__)

templates = [
  "default_new.webp",
  "2_lionel_messi.jpg",
  "3_elon_musk.jpg",
  "4_conor_mcgregor.jpg",
  "5_cristiano_ronaldo.jpg",
  "6_lionel_messi_2.jpg",
  "7_gates_of_olympus.jpg",
  "8_star_xu.jpg",
  "9_the_dog_house.jpg",
  "10_changpeng_zhao.jpg",
  "11_sky_bounty.jpg",
  "12_ben_zhou.jpg",
  "13_sweet_bonanza.jpg",
  "15_zeus_vs_hades.jpg",
  "16_chicken_cross.jpg",
  "17_sugar_rush.jpg",
  "18_aviamasters.jpg",
  "19_girl.jpg",
  "20_drake.jpg",
  "21_girl_2.jpg",
  "1_default.jpg",
  "green/default.jpg",
  "green/standard_2.jpg",
  "green/ronaldo.jpg",
  "green/ronaldo_2.jpg",
  "green/trump.jpg",
  "green/elon_musk.jpg",
  "green/mbappe.jpg",
  "green/angelina_jolie.jpg",
  "green/keanu_reeves.jpg",
  "green/50_cent.jpg",
  "green/kylie_jenner.jpg",
  "green/selena_gomez.jpg",
  "green/hades.jpg",
  "green/olympus.jpg",
  "green/plinko.jpg",
  "green/coinflip.jpg",
  "green/dice.jpg",
  "green/sugar_rush.jpg",
  "green/sweet_bonanza.jpg",
  "green/the_dog_house.jpg",
  "green/playboy.jpg",
  "green/girl.jpg",
  "green/girl2.jpg",
  "green/girl3.jpg",
  "green/girl4.jpg",
  "green/girl5.jpg",
  "green/brazzers.jpg"
]


@dp.message(States.start_input)
async def start_input(msg: types.Message, state: FSMContext):
    if msg.text:
        await state.clear()
        await msg.answer("👍 Отлично, теперь отправьте ссылку на свой профиль форума:")
        await state.set_state(States.start_sec_input)
        await state.update_data(exp=msg.text)


@dp.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=IS_NOT_MEMBER >> MEMBER))
async def bot_added_as_member(event: ChatMemberUpdated, state: FSMContext):
    await event.answer(f"ID: <code>{event.chat.id}</code>", parse_mode='HTML')

@dp.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=IS_NOT_MEMBER >> ADMINISTRATOR))
async def bot_added_as_member(event: ChatMemberUpdated, state: FSMContext):
    await event.answer(f"ID: <code>{event.chat.id}</code>", parse_mode='HTML')

@dp.message(States.start_sec_input)
async def start_sec_input(msg: types.Message, state: FSMContext):
    if msg.text:
        state_data = await state.get_data()
        exp = state_data["exp"]
        await state.clear()
        try:
            forum_url = msg.text
            DB.insert_new_user(user_id=msg.from_user.id, tg_username=msg.from_user.username, forum_url=forum_url, exp=exp)
            await utils.send_request_to_admin(msg, forum_url, exp)
            await msg.answer("✈️ Ваша заявка успешно отправлена! Ожидайте решения администрации")
        except Exception as e:
            logger.error(e)
            DB.delete(user_id=msg.from_user.id, table=DB.unconfirmed_users_table)
            await msg.answer("⛔️ Ваша заявка не была отправлена! Попробуйте еще раз")
        

@dp.message(States.change_username)
async def change_username(msg: types.Message, state: FSMContext):
    if msg.text:
        await state.clear()
        new_username = msg.text
        result = DB.update(user_id=msg.from_user.id, column="username", new_data=new_username, table=DB.users_table)
        if result is True:
            msg2edit = await msg.answer("✅️ Новый ник успешно сохранен!")
            await asyncio.sleep(2)
            await utils.show_user_profile(msg=msg, msg2edit=msg2edit)


@dp.message(States.link_wallet)
async def link_wallet(msg: types.Message, state: FSMContext):
    if msg.text:
        state_data = await state.get_data()
        wallet_name = str(state_data["wallet_name"]).lower()
        await state.clear()
        result = DB.update(user_id=msg.from_user.id, column=f"{wallet_name}_wallet", new_data=msg.text, table=DB.users_table)
        if result is True:
            await msg.answer(
                text=f"✅️ Новый адрес {wallet_name.upper()} кошелька успешно сохранен!",
            )
        else:
            await msg.answer(
                text=f"⛔️ Произошла ошибка при сохранении нового {wallet_name.upper()} кошелька!",
            )


@dp.message(States.payout_amount)
async def payout_amount(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        state_data = await state.get_data()
        await state.clear()
        amount_of_payout = float(msg.text)
        await utils.update_user_balance(
            user_id=msg.from_user.id,
            amount_of_payout=amount_of_payout,
            msg2edit=state_data["msg2edit"],
            wallet_name=state_data["wallet"]
        )


@dp.message(States.create_promo_amount)
async def create_promo_amount(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        await state.clear()
        amount = msg.text
        await msg.answer(
            text="💬 Введите название промокода"
        )
        await state.set_state(States.create_promo_name)
        await state.update_data(amount=amount)


@dp.message(States.create_promo_name)
async def create_promo_name(msg: types.Message, state: FSMContext):
    if msg.text:
        name = msg.text
        state_data = await state.get_data()
        amount = state_data["amount"]
        promos = DB.get_all(data="name", table=DB.promocodes)
        result_api = await get_promo(name)
        print(result_api)
        if (name.lower() in promos) or (isinstance(result_api, dict) and result_api.get("success") == True):
            await msg.answer(
                text="❌ Данный промокод уже существует, введите другой:"
            )
        else:
            await state.clear()
            create_promo_name_btns = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="❌ Включен", callback_data=f"promo_ubt_enable?{msg.from_user.id}_{name}_{amount}"), types.InlineKeyboardButton(text="✅ Отключен", callback_data=f"promo_ubt_disable?{msg.from_user.id}_{name}_{amount}")]
            ])
            text = """
💬 Выберите включен ли отыгрыш промокода
❗️Для УБТ рекомендуем оставлять его отключенным, а включенным только для профессионалов схемного траффика
                    """
            await msg.answer(
                text=text,
                reply_markup=create_promo_name_btns
            )
            
                
@dp.message(States.edit_promo_amount)
async def edit_promo_amount(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        new_amount = msg.text
        state_data = await state.get_data()
        promo_name = state_data["promo_name"]
        promo = await api.get_promo(promo_name)
        promo_ubt = promo["data"]["shouldWager"]
        await state.clear()
        try:
            cursor.execute(f"UPDATE promocodes SET amount = ? WHERE name = ?", (new_amount, promo_name))
            conn.commit()
            api_result = await api.edit_promo(
                {
                    'name': promo_name,
                    'amount': new_amount,
                    'shouldWager': promo_ubt,
                }
            )
            if api_result["success"] is True:
                await msg.answer(
                    text="✅️ Промокод успешно отредактирован!",
                )
            else:
                raise Exception
        except Exception:
            await msg.answer(
                text="❌ При редактировании промокода произошла ошибка!",
            )    



@dp.message(States.edit_info)
async def edit_info(msg: types.Message, state: FSMContext):
    if msg.text:
        try:
            DB.update_without_user_id(column="info", new_data=msg.html_text, table=DB.bot_info)
            await msg.answer("✅️ Информация сохранена!")
            await state.clear()
        except Exception as e:
            await msg.answer(f"❌ При сохранении информации произошла ошибка!")


@dp.message(States.edit_url)
async def edit_info(msg: types.Message, state: FSMContext):
    if msg.text:
        try:
            DB.update_without_user_id(column="actual_url", new_data=msg.text, table=DB.bot_info)
            await msg.answer("✅️ Актуальный домен сохранен!")
            await state.clear()
        except Exception as e:
            await msg.answer(f"❌ При сохранении домена произошла ошибка!")



@dp.message(States.edit_worker_perc)
async def edit_worker_perc(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        try:
            state_data = await state.get_data()
            worker_id = state_data["worker_id"]
            new_perc = msg.text
            result = DB.update(user_id=worker_id, column="percentage", new_data=new_perc, table=DB.users_table)
            result2 = DB.update(user_id=worker_id, column="percentage_edit_type", new_data="manual", table=DB.users_table)
            if result and result2:
                await msg.answer("✅️ Процент воркера успешно изменен!")
                await state.clear()
            else:
                raise Exception
        except Exception:
            await msg.answer("❌ При изменении процента воркера произошла ошибка!")


@dp.message(States.admin_ad)
async def admin_ad(msg: types.Message, state: FSMContext):
    if msg.text:
        btns = [
            [types.InlineKeyboardButton(text="❌ Отменить", callback_data="adminMsg_cancel"), types.InlineKeyboardButton(text="✅ Подтвердить", callback_data="adminMsg_accept")]
        ]

        await msg.answer(
            text="❗Подтвердите текст рассылки",
        )
        await msg.answer(
            text=msg.text,
            entities=msg.entities,
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns)
        )
        await state.clear()


@dp.message(States.admin_perc_change_all)
async def admin_perc_change_all(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        await state.clear()
        msg2edit = await msg.answer(
            text="⏳ Изменяю..."
        )
        new_perc = msg.text
        users = DB.get_all("user_id", DB.users_table)
        for user_id in users:
            DB.update(
                user_id=user_id,
                column="percentage",
                new_data=int(new_perc),
                table=DB.users_table
            )
        else:
            await msg2edit.edit_text(
                text="✅️ Процент у всех трафферов был изменен!"
            )
            

@dp.message(States.admin_perc_change_manual)
async def admin_perc_change_manual(msg: types.Message, state: FSMContext):
    if (msg.text).isdigit():
        await state.clear()
        msg2edit = await msg.answer(
            text="⏳ Изменяю..."
        )
        new_perc = msg.text
        users = DB.get_all("user_id", DB.users_table)
        for user_id in users:
            if DB.get(user_id=user_id, data="percentage_edit_type", table=DB.users_table) == "auto":
                DB.update(
                    user_id=user_id,
                    column="percentage",
                    new_data=int(new_perc),
                    table=DB.users_table
                )
            else:
                continue
        else:
            await msg2edit.edit_text(
                text="✅️ Процент у всех трафферов, кроме тех, кому меняли вручную был изменен!"
            )
            

@dp.message(States.user_input)
async def user_input(msg: types.Message, state: FSMContext):
    if msg.text:
        await state.clear()
        if msg.text.startswith("@"):
            worker_username = msg.text.split("@")[1]
            cursor.execute(f"SELECT user_id FROM {DB.users_table} WHERE tg_username = ?", (worker_username, ))
            worker_id = cursor.fetchone()[0]
            if worker_id is not None:
                text, worker_btns = await utils.create_worker_profile(worker_id)
                await msg.answer(
                    text=text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=worker_btns)
                )
        else:
            worker_id = msg.text
            result = DB.get(user_id=worker_id, data="user_id", table=DB.users_table)
            if result is not None:
                text, worker_btns = await utils.create_worker_profile(worker_id)
                await msg.answer(
                    text=text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=worker_btns)
                )

@dp.message(States.user_input_new_balance)
async def user_input_new_balance(msg: types.Message, state: FSMContext):
    if msg.text:

        data = await state.get_data()
        worker_id = data.get("worker_id")
        await state.clear()
        DB.update(user_id=worker_id, column="balance", new_data=float(msg.text), table=DB.users_table)

        await msg.answer("✅️ Баланс воркера был успешно изменен")



@dp.message(States.create_branch_name)
async def create_branch_name(msg: types.Message, state: FSMContext):
    logger.info(f"create_branch_name: {msg.text}")
    if msg.text:
        branch_name = msg.text
        await state.update_data(branch_name=branch_name)
        state_data = await state.get_data()
        msg2edit = state_data["msg2edit"]
        await msg2edit.answer(text="👤 Введите ID овнера филиала:")
        await state.set_state(States.create_branch_owner)


@dp.message(States.create_branch_owner)
async def create_branch_owner(msg: types.Message, state: FSMContext):
    logger.info(f"create_branch_owner: {msg.text}")
    if msg.text.isdigit():
        owner_id = int(msg.text)
        await state.update_data(owner_id=owner_id)
        state_data = await state.get_data()
        msg2edit = state_data["msg2edit"]
        await msg2edit.answer(text="📊 Введите процент филиала:")
        await state.set_state(States.create_branch_percentage)


@dp.message(States.create_branch_percentage)
async def create_branch_percentage(msg: types.Message, state: FSMContext):
    logger.info(f"create_branch_percentage: {msg.text}")
    if msg.text.isdigit():
        percentage = int(msg.text)
        state_data = await state.get_data()
        branch_name = state_data["branch_name"]
        owner_id = state_data["owner_id"]
        await state.clear()
        try:
            DB.insert_branch(owner_id=owner_id, name=branch_name, percentage=percentage)
            msg2edit = state_data["msg2edit"]
            await msg2edit.answer(text="✅ Филиал успешно создан!")
        except Exception as e:
            logger.error(e)
            msg2edit = state_data["msg2edit"]
            await msg2edit.answer(text="❌ Ошибка при создании филиала!")

@dp.message(States.choose_domain_template)
async def process_choose_domain_template(msg: types.Message, state: FSMContext):

    pass

@dp.message(States.add_domain_input_name)
async def add_domain_input_name(msg: types.Message, state: FSMContext):
    user_id = msg.from_user.id
    domain_name_raw = msg.text.strip().lower()

    if not re.match(r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$", domain_name_raw):
        error_text = "❌ Неверный формат домена. Введите корректно (example.com) или нажмите 'Отмена'."
        markup_cancel = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="< Отмена и назад к доменам", callback_data="user_my_domains_list?0")]])
        await msg.answer(error_text, reply_markup=markup_cancel)
        return

    existing_domains_data = DB.get_user_domains(user_id)
    if existing_domains_data and any(
            d[1].lower() == domain_name_raw for d in existing_domains_data if d and len(d) > 1):
        error_text = f"❌ Домен {domain_name_raw} уже есть в вашем списке."
        markup_cancel = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="< Назад к доменам", callback_data="user_my_domains_list?0")]])
        await msg.answer(error_text, reply_markup=markup_cancel)
        await state.clear()
        return

    await state.update_data(domain_name_raw=domain_name_raw)

    add_result = await api.add_user_domain(domain_name_raw)
    if add_result.get("success"):
        template_result = await api.set_domain_template(domain_name_raw, templates[0].split('/')[-1].split('.')[0])
        if template_result.get("success"):
            DB.add_user_domain(user_id=user_id, domain_name=domain_name_raw, status="pending")
            await msg.answer(f"✅ Домен {domain_name_raw} успешно добавлен с шаблоном '{templates[0]}'!")
            await utils.show_user_domains_list(msg)
        else:
            await msg.answer("❌ Ошибка установки шаблона.")
    else:
        await msg.answer("❌ Ошибка добавления домена.")
    await state.clear()


@dp.message()
async def messages_handler(msg: types.Message, state: FSMContext):
    if msg.text == "👨‍💻 Профиль":
        msg2edit = await msg.answer("Загрузка...")
        await utils.show_user_profile(msg=msg, msg2edit=msg2edit)
    elif msg.text == "📕 Материалы":
        materials_btns = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="🎟 Создать промокод", callback_data="create_promo"),
             types.InlineKeyboardButton(text="❌ Удалить промокод", callback_data="delete_promo")],
            [types.InlineKeyboardButton(text="📋 Статистика промокодов", callback_data="stats_promo"),
             types.InlineKeyboardButton(text="✍️ Редактировать промокод", callback_data="edit_promo")],
            [types.InlineKeyboardButton(text="< Назад", callback_data="back_main")]
        ])
        await msg.delete()
        await msg.answer(
            text="📕 Материалы",
            reply_markup=materials_btns
        )
    elif msg.text == "🔗 Актуальный домен":
        actual_url = DB.get_without_user_id(data="actual_url", table=DB.bot_info)
        text = f'''
🔗 Актуальный домен

👉 {actual_url}'''
        await msg.delete()
        await msg.answer(
            text=text,
            reply_markup=types.InlineKeyboardMarkup(
                inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_main")]])
        )
    elif msg.text == "ℹ️ Информация":
        text = DB.get_without_user_id(data="info", table=DB.bot_info)
        text = f'''
ℹ️ Информация

{text}'''
        await msg.delete()
        await msg.answer(
            text=text,
            reply_markup=types.InlineKeyboardMarkup(
                inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_main")]]),
            parse_mode="HTML"
        )
    elif msg.text == "🏢 Создать филиал":
        await msg.answer("💬 Введите название филиала:")
        await state.set_state(States.create_branch_name)
    elif msg.text == "🏢 Выбрать филиал":
        branches = DB.get_all(data="name", table=DB.branches_table)
        if branches:
            btns = []
            for branch in branches:
                btns.append([types.InlineKeyboardButton(text=f"🏢 {branch}", callback_data=f"select_branch_{branch}")])
            btns.append([types.InlineKeyboardButton(text="< Назад", callback_data="back_main")])
            await msg.answer("Выберите филиал:", reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns))
        else:
            await msg.answer("Нет доступных филиалов.")
    elif msg.text == "🥇 Топ депозитов":
        top_deposits_btns = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="📅 За день", callback_data="top_deposits_day"), types.InlineKeyboardButton(text="📅 За неделю", callback_data="top_deposits_week")],
            [types.InlineKeyboardButton(text="📅 За месяц", callback_data="top_deposits_month"), types.InlineKeyboardButton(text="📅 За всё время", callback_data="top_deposits_all")],
            [types.InlineKeyboardButton(text="< Назад", callback_data="back_main")]
        ])
        await msg.delete()
        await msg.answer(
            text="🥇 Выберите период для топа депозитов:",
            reply_markup=top_deposits_btns
        )
    elif msg.text == "🏷 Добавить домен":
        await msg.answer("💬 Введите домен (example.com):")
        await state.set_state(States.add_domain_input_name)

    elif msg.text == "🔙 Назад в главное меню":
        await state.clear()
        await msg.answer(
            text="Вы вернулись в главное меню.",
            reply_markup=types.ReplyKeyboardMarkup(
                keyboard=[
                    [types.KeyboardButton(text="👨‍💻 Профиль")],
                    [types.KeyboardButton(text="📕 Материалы")],
                    [types.KeyboardButton(text="🔗 Актуальный домен")],
                    [types.KeyboardButton(text="ℹ️ Информация")],
                    [types.KeyboardButton(text="🏢 Создать филиал")],
                    [types.KeyboardButton(text="🏢 Выбрать филиал")],
                    [types.KeyboardButton(text="🥇 Топ депозитов")],
                    [types.KeyboardButton(text="🏷 Добавить домен")],
                    [types.KeyboardButton(text="📂 Мои домены")]
                ],
                resize_keyboard=True
            )
        )
    elif msg.text == "⬅️ Назад":
        await state.clear()
        await msg.answer("Вы вернулись назад.", reply_markup=types.ReplyKeyboardRemove())
    elif msg.text == "❌ Отменить":
        await state.clear()
        await msg.answer("Операция отменена.", reply_markup=types.ReplyKeyboardRemove())
    elif msg.text == "✅ Подтвердить":
        await msg.answer("Операция подтверждена.", reply_markup=types.ReplyKeyboardRemove())
    elif msg.text == "📅 За день":
        await msg.answer("Топ депозитов за день:")
    elif msg.text == "📅 За неделю":
        await msg.answer("Топ депозитов за неделю:")
    elif msg.text == "📅 За месяц":
        await msg.answer("Топ депозитов за месяц:")
    elif msg.text == "📅 За всё время":
        await msg.answer("Топ депозитов за всё время:")
    else:
        await msg.answer("Неизвестная команда. Пожалуйста, выберите действие из меню.")
